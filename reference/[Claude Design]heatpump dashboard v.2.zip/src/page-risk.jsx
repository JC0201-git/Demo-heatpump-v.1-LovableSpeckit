/* global React, HPMD, Icons, StatusPill, RiskBadge, Sparkline,
   useApp, useLiveTick, fmtTime */
// ============================================================
// Page 2 — 風險排序 Risk Ranking (P2)
// ============================================================
function PageRisk() {
  const { siteId, openDevice, role } = useApp();
  const tick = useLiveTick(6000);
  const [filter, setFilter] = React.useState("ALL");
  const [editing, setEditing] = React.useState(null); // device id

  const sorted = React.useMemo(() => {
    const arr = HPMD.devices.filter((d) => siteId === "ALL" || d.site_id === siteId);
    return arr
      .filter((d) => filter === "ALL" || d.risk_level === filter)
      .sort((a, b) => HPMD.devices.indexOf(a) && 0 || HPMD.devices.indexOf(b) && 0 || (riskScore(b) - riskScore(a)));
  }, [siteId, filter]);

  const counts = React.useMemo(() => {
    const c = { high: 0, mid: 0, low: 0 };
    HPMD.devices.filter((d) => siteId === "ALL" || d.site_id === siteId).forEach((d) => c[d.risk_level]++);
    return c;
  }, [siteId]);

  return (
    <div>
      <div className="page-head">
        <div>
          <div className="num">P2 · RISK PRIORITIZATION</div>
          <h1>風險排序</h1>
          <div className="sub">由維運人員手動指派風險等級（v1）· v2 將升級為多指標加權自動評分</div>
        </div>
        <div className="actions">
          <div className="segmented">
            <button className={filter === "ALL" ? "on" : ""} onClick={() => setFilter("ALL")}>全部 {sorted.length || HPMD.devices.length}</button>
            <button className={filter === "high" ? "on" : ""} onClick={() => setFilter("high")}>高 {counts.high}</button>
            <button className={filter === "mid" ? "on" : ""} onClick={() => setFilter("mid")}>中 {counts.mid}</button>
            <button className={filter === "low" ? "on" : ""} onClick={() => setFilter("low")}>低 {counts.low}</button>
          </div>
        </div>
      </div>

      {/* summary row */}
      <div className="grid-3" style={{ marginBottom: 16 }}>
        <RiskCard level="high" count={counts.high} note="須立即處理 · 高機率影響營運" />
        <RiskCard level="mid"  count={counts.mid}  note="排程處理 · 持續觀察趨勢" />
        <RiskCard level="low"  count={counts.low}  note="例行維護 · 風險可接受" />
      </div>

      <div className="card">
        <div className="card-head">
          <div className="ic"><Icons.Triangle size={14} /></div>
          <h4>風險清單</h4>
          <span className="sub">依風險等級 → 告警數 → 異常分數排序</span>
          <div style={{ marginLeft: "auto" }}>
            <button className="btn"><Icons.Download size={14} />匯出 CSV</button>
          </div>
        </div>
        <div className="card-body" style={{ padding: 0 }}>
          <div style={{ overflowX: "auto" }}>
            <table className="dt">
              <thead>
                <tr>
                  <th>排序</th>
                  <th>等級</th>
                  <th>編號 / 名稱</th>
                  <th>場域</th>
                  <th>狀態</th>
                  <th>運轉指標</th>
                  <th>近 30 日告警</th>
                  <th>備註</th>
                  <th>指派</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {sorted.slice(0, 25).map((d, i) => {
                  const r = HPMD.readingsFor(d, Date.now() + tick * 6000);
                  const alertCount = HPMD.alerts.filter((a) => a.device_id === d.device_id).length;
                  return (
                    <tr key={d.device_id} onClick={() => openDevice(d.device_id)}>
                      <td className="mono dimmer">{String(i + 1).padStart(2, "0")}</td>
                      <td><RiskBadge level={d.risk_level} /></td>
                      <td>
                        <div style={{ fontSize: 12, color: "var(--fg-0)", fontWeight: 500 }}>{d.name}</div>
                        <div className="mono dimmer" style={{ fontSize: 10 }}>{d.device_id}</div>
                      </td>
                      <td className="dim">{d.site_name}</td>
                      <td><StatusPill status={d.status} dim /></td>
                      <td>
                        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                          <Sparkline data={trendForDevice(d, "temp_outlet").slice(-40)} width={70} height={22} color={d.status === "alarm" ? "var(--alarm)" : "var(--lime)"} />
                          <div style={{ fontSize: 10, fontFamily: "var(--mono)", color: "var(--fg-2)" }}>
                            <div>T_out {r ? r.temp_outlet.toFixed(1) : "—"}°C</div>
                            <div className="dimmer">COP {r ? r.cop.toFixed(2) : "—"}</div>
                          </div>
                        </div>
                      </td>
                      <td className="num">
                        <span style={{ color: alertCount > 3 ? "var(--alarm)" : alertCount > 1 ? "var(--warn)" : "var(--fg-2)" }}>{alertCount}</span>
                      </td>
                      <td style={{ maxWidth: 200, color: "var(--fg-2)", fontSize: 11 }}>{d.risk_note}</td>
                      <td>
                        <div style={{ fontSize: 11, color: "var(--fg-1)" }}>{d.risk_assigned_by}</div>
                        <div className="mono dimmer" style={{ fontSize: 10 }}>{d.risk_assigned_at}</div>
                      </td>
                      <td>
                        {role === "operator" ? (
                          <button className="btn" style={{ height: 26, padding: "0 10px", fontSize: 11 }} onClick={(e) => { e.stopPropagation(); setEditing(d.device_id); }}>
                            <Icons.Tool size={12} /> 重新指派
                          </button>
                        ) : (
                          <span className="dimmer mono" style={{ fontSize: 10 }}>唯讀</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {sorted.length > 25 && (
            <div style={{ padding: 12, textAlign: "center", color: "var(--fg-3)", fontSize: 11 }}>
              顯示前 25 筆 · 共 {sorted.length} 筆 · 套用篩選縮小範圍
            </div>
          )}
        </div>
      </div>

      {editing && <AssignDialog deviceId={editing} onClose={() => setEditing(null)} />}
    </div>
  );
}

function RiskCard({ level, count, note }) {
  const r = window.RISK[level];
  return (
    <div className="kpi-card" style={{ flexDirection: "row", gap: 14, padding: 16, alignItems: "center" }}>
      <div style={{ width: 48, height: 48, borderRadius: 12, background: `color-mix(in oklab, ${r.color} 16%, transparent)`, color: r.color, display: "grid", placeItems: "center" }}>
        <Icons.Triangle size={22} />
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, color: "var(--fg-3)", fontFamily: "var(--mono)", textTransform: "uppercase", letterSpacing: ".08em" }}>{r.label}風險</div>
        <div className="val val-num" style={{ color: r.color, fontSize: 28 }}>{count}<span style={{ fontSize: 12, color: "var(--fg-3)", marginLeft: 4 }}>台</span></div>
        <div style={{ fontSize: 11, color: "var(--fg-2)", marginTop: 2 }}>{note}</div>
      </div>
    </div>
  );
}

function AssignDialog({ deviceId, onClose }) {
  const device = HPMD.devices.find((d) => d.device_id === deviceId);
  const [level, setLevel] = React.useState(device.risk_level);
  const [note, setNote] = React.useState(device.risk_note);
  return (
    <>
      <div className="drawer-backdrop on" onClick={onClose} />
      <div className="drawer on" style={{ width: 480 }}>
        <div style={{ padding: 24 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
            <div>
              <div className="num eyebrow">RISK ASSIGNMENT</div>
              <h2 style={{ margin: "4px 0 0", fontSize: 20 }}>{device.name}</h2>
              <div className="mono dimmer" style={{ fontSize: 11 }}>{device.device_id} · {device.site_name}</div>
            </div>
            <button className="btn-icon btn ghost" onClick={onClose}><Icons.X size={14} /></button>
          </div>

          <div style={{ marginBottom: 20 }}>
            <div className="eyebrow" style={{ marginBottom: 10 }}>風險等級</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
              {["high", "mid", "low"].map((lv) => {
                const r = window.RISK[lv];
                return (
                  <button key={lv} className="btn" onClick={() => setLevel(lv)}
                    style={{
                      height: 76, flexDirection: "column", gap: 6,
                      borderColor: level === lv ? r.color : "var(--line-soft)",
                      background: level === lv ? `color-mix(in oklab, ${r.color} 16%, var(--bg-1))` : "var(--bg-1)",
                    }}>
                    <span style={{ color: r.color, fontSize: 18, fontFamily: "var(--mono)", fontWeight: 500 }}>{r.label}</span>
                    <span style={{ color: "var(--fg-2)", fontSize: 10 }}>{lv === "high" ? "立即處理" : lv === "mid" ? "排程處理" : "例行維護"}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div style={{ marginBottom: 20 }}>
            <div className="eyebrow" style={{ marginBottom: 6 }}>指派備註</div>
            <textarea value={note} onChange={(e) => setNote(e.target.value)} rows="4"
              style={{
                width: "100%", padding: 10, borderRadius: 8,
                background: "var(--bg-1)", color: "var(--fg-0)",
                border: "1px solid var(--line-soft)", fontFamily: "var(--sans)", fontSize: 12,
                resize: "vertical", outline: "none",
              }} />
          </div>

          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
            <button className="btn" onClick={onClose}>取消</button>
            <button className="btn primary" onClick={() => { device.risk_level = level; device.risk_note = note; device.risk_assigned_by = "李維運"; device.risk_assigned_at = new Date().toISOString().slice(0, 10); onClose(); }}>
              <Icons.Check size={14} /> 確認指派
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

function riskScore(d) {
  const lv = { high: 300, mid: 150, low: 30 }[d.risk_level] || 0;
  const st = { alarm: 100, warn: 50, ok: 0, idle: -10, offline: 80 }[d.status] || 0;
  return lv + st;
}

function trendForDevice(d, k) {
  if (!d._trends) d._trends = HPMD.buildTrends(d);
  return d._trends[k] || [];
}

window.PageRisk = PageRisk;
