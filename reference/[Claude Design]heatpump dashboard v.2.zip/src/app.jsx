/* global React, ReactDOM, AppProvider, useApp, TopBar, SideRail,
   PageOverview, PageRisk, PageDevice, PageAlerts, PageReport, PageExec,
   NoPermission, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor */
// ============================================================
// Heat Pump Monitor — App entry
// ============================================================
function PageRouter() {
  const { page, role } = useApp();
  // role guard
  if (page === "report" && role !== "manager") return <NoPermission />;
  if (page === "exec" && role !== "manager") return <NoPermission />;
  if (page === "overview") return <PageOverview />;
  if (page === "risk")     return <PageRisk />;
  if (page === "device")   return <PageDevice />;
  if (page === "alerts")   return <PageAlerts />;
  if (page === "report")   return <PageReport />;
  if (page === "exec")     return <PageExec />;
  return <PageOverview />;
}

function App() {
  // Tweaks-controlled appearance settings
  const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
    "theme": "dark",
    "accent": "lime",
    "density": "comfortable"
  }/*EDITMODE-END*/;
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);

  React.useEffect(() => {
    document.documentElement.dataset.theme = tweaks.theme;
    document.documentElement.dataset.accent = tweaks.accent;
    document.documentElement.dataset.density = tweaks.density;
  }, [tweaks]);

  return (
    <AppProvider>
      <div className="app">
        <SideRail />
        <TopBar />
        <main className="main">
          <div className="main-inner">
            <PageRouter />
          </div>
        </main>
      </div>

      <TweaksPanel title="Tweaks · 介面調整">
        <TweakSection label="主題">
          <TweakRadio
            label="配色模式"
            value={tweaks.theme}
            onChange={(v) => setTweak("theme", v)}
            options={[
              { value: "dark",  label: "深色" },
              { value: "light", label: "淺色" },
            ]}
          />
          <TweakRadio
            label="強調色"
            value={tweaks.accent}
            onChange={(v) => setTweak("accent", v)}
            options={[
              { value: "lime",  label: "Lime" },
              { value: "blue",  label: "Blue" },
              { value: "amber", label: "Amber" },
              { value: "cyan",  label: "Cyan" },
            ]}
          />
          <TweakRadio
            label="資訊密度"
            value={tweaks.density}
            onChange={(v) => setTweak("density", v)}
            options={[
              { value: "comfortable", label: "舒適" },
              { value: "compact",     label: "緊湊" },
            ]}
          />
        </TweakSection>
        <TweakSection label="說明">
          <div style={{ fontSize: 11, color: "var(--fg-2)", lineHeight: 1.6 }}>
            <p style={{ margin: "0 0 8px" }}>
              <b>角色切換</b>位於右上工具列 — 維運人員（可寫）、高層管理者（唯讀，可看月報/決策頁）。
            </p>
            <p style={{ margin: "0 0 8px" }}>
              <b>場域切換</b>位於左上 — 切換後所有頁面同步篩選。
            </p>
            <p style={{ margin: 0 }}>
              <b>即時資料</b>每 6 秒微動，反映 5 分鐘採集週期。
            </p>
          </div>
        </TweakSection>
      </TweaksPanel>
    </AppProvider>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
