/* global React, HPMD, Icons, StatusPill, SeverityPill, StackedBars, Donut, LineChart,
   useApp, fmtTime */
// ============================================================
// Page 5 — 月報雛形 Monthly Report (P5, manager only)
// ============================================================
function PageReport() {
  const [site, setSite] = React.useState("SITE01");
  const [month, setMonth] = React.useState("2026-04");
  const [generated, setGenerated] = React.useState(true);

  const report = React.useMemo(() => buildReport(site, month), [site, month, generated]);

  return (
    <div>
      <div className="page-head no-print">
        <div>
          <div className="num">P5 · MONTHLY REPORT</div>
          <h1>月報雛形</h1>
          <div className="sub">客戶端設備運行月度摘要 · HTML 預覽，列印另存 PDF</div>
        </div>
        <div className="actions">
          <select value={site} onChange={(e) => setSite(e.target.value)} className="btn" style={{ height: 32, padding: "0 12px", appearance: "menulist" }}>
            {HPMD.sites.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <select value={month} onChange={(e) => setMonth(e.target.value)} className="btn" style={{ height: 32, padding: "0 12px", appearance: "menulist" }}>
            {["2026-05", "2026-04", "2026-03", "2026-02", "2026-01"].map((m) => <option key={m} value={m}>{m}</option>)}
          </select>
          <button className="btn primary" onClick={() => setGenerated((g) => !g)}><Icons.Refresh size={14} />重新產生</button>
          <button className="btn" onClick={() => window.print()}><Icons.Print size={14} />列印 / 另存 PDF</button>
        </div>
      </div>

      {/* report */}
      <div className="report-page" style={{ background: "var(--bg-1)", padding: "32px 48px", borderRadius: 12, boxShadow: "var(--shadow-card)", maxWidth: 880, margin: "0 auto" }}>
        {/* header */}
        <div style={{ borderBottom: "2px solid var(--lime)", paddingBottom: 16, marginBottom: 20, display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
          <div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--fg-3)", letterSpacing: ".12em", textTransform: "uppercase" }}>Heatpump Performance Report</div>
            <h2 style={{ margin: "4px 0 0", fontSize: 22 }}>{report.siteName}</h2>
            <div className="dim" style={{ fontSize: 12, marginTop: 2 }}>{report.city} · {report.deviceCount} 台設備 · {month} 月份報告</div>
          </div>
          <div style={{ textAlign: "right", fontSize: 11, color: "var(--fg-3)", fontFamily: "var(--mono)" }}>
            <div>產生時間 {fmtTime(new Date())}</div>
            <div>Report v1.0 · 內部資料</div>
          </div>
        </div>

        {/* exec summary */}
        <SectionTitle num="01" title="重點摘要" />
        <p style={{ fontSize: 13, lineHeight: 1.7, color: "var(--fg-1)" }}>
          本月 <b style={{ color: "var(--lime)" }}>{report.siteName}</b> 共 {report.deviceCount} 台熱泵設備在線運轉，
          整體可用率達 <b className="val-num" style={{ color: "var(--ok)" }}>{report.availability}%</b>，
          較上月 <b className="val-num">{report.availabilityChange > 0 ? `+${report.availabilityChange}` : report.availabilityChange}%</b>。
          本月共產生 <b className="val-num">{report.totalAlerts}</b> 筆告警，其中嚴重事件 {report.criticalCount} 筆均已於 24 小時內完成處理。
          {report.criticalCount === 0 ? " 本月無重大異常事件，設備運行正常。" : " 詳細處理紀錄請見第 04 節。"}
        </p>

        {/* KPI strip */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginTop: 16, marginBottom: 20 }}>
          <ReportKPI label="平均可用率" value={`${report.availability}%`} sub={`${report.availabilityChange >= 0 ? "▲" : "▼"} ${Math.abs(report.availabilityChange)}% vs ${month === "2026-05" ? "2026-04" : "上月"}`} color="var(--ok)" />
          <ReportKPI label="總用電量" value={report.energyKWh.toLocaleString()} unit="kWh" sub={`▼ ${(2 + Math.random() * 3).toFixed(1)}% vs 上月`} color="var(--lime)" />
          <ReportKPI label="平均 COP" value={report.avgCop.toFixed(2)} sub={`基準值 3.5`} color="var(--info)" />
          <ReportKPI label="告警總數" value={report.totalAlerts} sub={`嚴重 ${report.criticalCount} · 警告 ${report.warningCount}`} color={report.criticalCount > 0 ? "var(--warn)" : "var(--ok)"} />
        </div>

        {/* device availability */}
        <SectionTitle num="02" title="設備可用率明細" />
        <table className="dt" style={{ marginBottom: 20 }}>
          <thead>
            <tr><th>設備</th><th>編號</th><th style={{ textAlign: "right" }}>運轉時數</th><th style={{ textAlign: "right" }}>用電量 (kWh)</th><th style={{ textAlign: "right" }}>平均 COP</th><th style={{ textAlign: "right" }}>可用率</th><th>本月最常告警</th></tr>
          </thead>
          <tbody>
            {report.devices.map((d) => (
              <tr key={d.device_id} style={{ cursor: "default" }}>
                <td>{d.name}</td>
                <td className="mono dim">{d.device_id}</td>
                <td className="num">{d.runtime}</td>
                <td className="num">{d.energy}</td>
                <td className="num">{d.cop}</td>
                <td className="num" style={{ color: d.availability > 98 ? "var(--ok)" : d.availability > 92 ? "var(--warn)" : "var(--alarm)" }}>{d.availability.toFixed(1)}%</td>
                <td className="dim" style={{ fontSize: 11 }}>{d.topAlert}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* alert distribution */}
        <SectionTitle num="03" title="告警類型分佈" />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
          <div style={{ background: "var(--bg-2)", padding: 16, borderRadius: 8 }}>
            <StackedBars data={report.dailyAlerts} width={400} height={140} colors={{ critical: "var(--alarm)", warning: "var(--warn)", info: "var(--info)" }} />
            <div className="dim" style={{ fontSize: 11, textAlign: "center", marginTop: 8 }}>每日告警筆數 (本月)</div>
          </div>
          <div style={{ background: "var(--bg-2)", padding: 16, borderRadius: 8 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <Donut size={120} stroke={14} slices={[
                { value: report.criticalCount, color: "var(--alarm)" },
                { value: report.warningCount, color: "var(--warn)" },
                { value: Math.max(0, report.totalAlerts - report.criticalCount - report.warningCount), color: "var(--info)" },
              ]} center={{ value: report.totalAlerts, label: "TOTAL" }} />
              <div style={{ fontSize: 12, color: "var(--fg-1)", display: "grid", rowGap: 8 }}>
                <div><span style={{ display: "inline-block", width: 8, height: 8, background: "var(--alarm)", borderRadius: 2, marginRight: 6 }} />嚴重 <span className="val-num">{report.criticalCount}</span></div>
                <div><span style={{ display: "inline-block", width: 8, height: 8, background: "var(--warn)", borderRadius: 2, marginRight: 6 }} />警告 <span className="val-num">{report.warningCount}</span></div>
                <div><span style={{ display: "inline-block", width: 8, height: 8, background: "var(--info)", borderRadius: 2, marginRight: 6 }} />資訊 <span className="val-num">{report.totalAlerts - report.criticalCount - report.warningCount}</span></div>
              </div>
            </div>
            <div className="dim" style={{ fontSize: 11, textAlign: "center", marginTop: 8 }}>嚴重度分佈</div>
          </div>
        </div>

        {/* critical events */}
        <SectionTitle num="04" title="重大事件摘要" />
        {report.criticalEvents.length === 0 ? (
          <div style={{ padding: 24, background: "color-mix(in oklab, var(--ok) 10%, transparent)", borderRadius: 8, borderLeft: "3px solid var(--ok)", marginBottom: 20 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
              <Icons.Check size={16} /> <b>本月無異常事件</b>
            </div>
            <div className="dim" style={{ fontSize: 12 }}>所有設備運行正常，未發生嚴重等級告警。</div>
          </div>
        ) : (
          <table className="dt" style={{ marginBottom: 20 }}>
            <thead>
              <tr><th>日期</th><th>設備</th><th>事件</th><th>處理人員</th><th>處理時長</th><th>結果</th></tr>
            </thead>
            <tbody>
              {report.criticalEvents.map((e, i) => (
                <tr key={i} style={{ cursor: "default" }}>
                  <td className="mono">{e.date}</td>
                  <td>{e.device}</td>
                  <td style={{ color: "var(--alarm)" }}>{e.event}</td>
                  <td className="dim">{e.handler}</td>
                  <td className="num">{e.duration}</td>
                  <td className="dim" style={{ fontSize: 11 }}>{e.outcome}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* footer */}
        <div style={{ borderTop: "1px solid var(--line-soft)", paddingTop: 12, marginTop: 24, display: "flex", justifyContent: "space-between", fontSize: 11, color: "var(--fg-3)", fontFamily: "var(--mono)" }}>
          <span>{report.siteName} · {month}</span>
          <span>Page 1 / 1 · Generated by Heatpump IIoT v0.1</span>
        </div>
      </div>
    </div>
  );
}

function SectionTitle({ num, title }) {
  return (
    <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginTop: 16, marginBottom: 12 }}>
      <span style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--lime)", letterSpacing: ".12em" }}>{num}</span>
      <h3 style={{ margin: 0, fontSize: 15, fontWeight: 600, color: "var(--fg-0)" }}>{title}</h3>
      <span style={{ flex: 1, height: 1, background: "var(--line-soft)", marginLeft: 4 }} />
    </div>
  );
}

function ReportKPI({ label, value, unit, sub, color }) {
  return (
    <div style={{ background: "var(--bg-2)", padding: "14px 16px", borderRadius: 8, borderTop: `2px solid ${color}` }}>
      <div style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--fg-3)", textTransform: "uppercase", letterSpacing: ".08em" }}>{label}</div>
      <div className="val-num" style={{ fontSize: 24, color, marginTop: 4 }}>{value}{unit && <span style={{ fontSize: 11, color: "var(--fg-3)", marginLeft: 3 }}>{unit}</span>}</div>
      <div style={{ fontSize: 10, color: "var(--fg-3)", marginTop: 2 }}>{sub}</div>
    </div>
  );
}

function buildReport(siteId, month) {
  const site = HPMD.sites.find((s) => s.id === siteId);
  const devices = HPMD.devices.filter((d) => d.site_id === siteId);
  const top = devices.slice(0, 8).map((d, i) => ({
    name: d.name,
    device_id: d.device_id,
    runtime: (550 + Math.floor(Math.random() * 180)),
    energy: (1800 + Math.floor(Math.random() * 1400)).toLocaleString(),
    cop: (3.2 + Math.random() * 1.1).toFixed(2),
    availability: 90 + Math.random() * 9.9,
    topAlert: ["—", "出水溫度過高 × 2", "壓縮機振動偏高 × 1", "—", "高壓壓力 × 1", "—", "—", "—"][i],
  }));
  const totalEnergy = top.reduce((s, d) => s + parseInt(d.energy.replace(/,/g, ""), 10), 0);

  // synthetic alert counts
  const totalAlerts = 12 + Math.floor(Math.random() * 18);
  const criticalCount = Math.floor(Math.random() * 4);
  const warningCount = Math.floor(totalAlerts * 0.5);

  // daily alerts
  const dailyAlerts = [];
  for (let day = 1; day <= 30; day += 3) {
    const segs = {
      critical: Math.random() < 0.25 ? 1 : 0,
      warning: Math.floor(Math.random() * 3),
      info: Math.floor(Math.random() * 2),
    };
    dailyAlerts.push({
      label: `${day}`,
      segments: [
        { key: "info", value: segs.info },
        { key: "warning", value: segs.warning },
        { key: "critical", value: segs.critical },
      ],
    });
  }

  // critical events
  const criticalEvents = criticalCount > 0 ? Array.from({ length: criticalCount }, (_, i) => ({
    date: `${month}-${String(3 + i * 7).padStart(2, "0")}`,
    device: top[i % top.length].name,
    event: ["出水溫度超危急值", "壓縮機振動嚴重", "循環流量過低", "高壓壓力危急"][i % 4],
    handler: ["陳工程", "李維運", "外包-冠軒工程"][i % 3],
    duration: `${1 + Math.floor(Math.random() * 5)}h ${Math.floor(Math.random() * 50)}m`,
    outcome: ["更換高壓開關後恢復", "清洗冷凝器、補充冷媒", "重新校正流量計", "重啟壓縮機後正常"][i % 4],
  })) : [];

  return {
    siteName: site.name,
    city: site.city,
    deviceCount: devices.length,
    availability: (95 + Math.random() * 4.5).toFixed(1),
    availabilityChange: (Math.random() * 2 - 0.5).toFixed(1) * 1,
    energyKWh: totalEnergy,
    avgCop: 3.4 + Math.random() * 0.7,
    totalAlerts, criticalCount, warningCount,
    devices: top,
    dailyAlerts,
    criticalEvents,
  };
}

window.PageReport = PageReport;
