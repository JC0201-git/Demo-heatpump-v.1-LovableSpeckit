/* global React, ReactDOM, HPMD, Icons, useClock */
// ============================================================
// Heat Pump Monitor — App Shell + Router
// ============================================================
const PAGES = [
  { id: "overview",  label: "設備總覽",   icon: Icons.Home,   roles: ["operator", "manager"] },
  { id: "risk",      label: "風險排序",   icon: Icons.Triangle, roles: ["operator", "manager"] },
  { id: "device",    label: "單機履歷",   icon: Icons.Grid,   roles: ["operator", "manager"] },
  { id: "alerts",    label: "告警中心",   icon: Icons.Alarm,  roles: ["operator", "manager"] },
  { id: "report",    label: "月報",       icon: Icons.File,   roles: ["manager"] },
  { id: "exec",      label: "決策總覽",   icon: Icons.Crown,  roles: ["manager"] },
];

// ============================================================
// AppContext — shared state
// ============================================================
const AppCtx = React.createContext(null);
const useApp = () => React.useContext(AppCtx);

function AppProvider({ children }) {
  const [role, setRole] = React.useState(() => localStorage.getItem("hpmd_role") || "operator");
  const [page, setPage] = React.useState("overview");
  const [siteId, setSiteId] = React.useState("ALL");
  const [activeDeviceId, setActiveDeviceId] = React.useState(null);
  const [alerts, setAlerts] = React.useState(HPMD.alerts);

  React.useEffect(() => { localStorage.setItem("hpmd_role", role); }, [role]);

  // Redirect off manager-only pages when switching to operator
  React.useEffect(() => {
    const cur = PAGES.find((p) => p.id === page);
    if (cur && !cur.roles.includes(role)) setPage("overview");
  }, [role, page]);

  const openDevice = React.useCallback((id) => {
    setActiveDeviceId(id);
    setPage("device");
  }, []);

  const acknowledgeAlert = React.useCallback((id, by) => {
    setAlerts((all) => all.map((a) => a.id === id
      ? { ...a, status: "acknowledged", acknowledged_at: new Date().toISOString(), acknowledged_by: by }
      : a));
  }, []);
  const resolveAlert = React.useCallback((id, by, note) => {
    setAlerts((all) => all.map((a) => a.id === id
      ? { ...a, status: "resolved", resolved_at: new Date().toISOString(), acknowledged_by: a.acknowledged_by || by, note: note || "現場處理完成" }
      : a));
  }, []);

  const value = {
    role, setRole,
    page, setPage,
    siteId, setSiteId,
    activeDeviceId, openDevice,
    alerts, acknowledgeAlert, resolveAlert,
  };
  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

// ============================================================
// Topbar — brand, site picker, live clock, role switch
// ============================================================
function TopBar() {
  const { siteId, setSiteId, role, setRole, page } = useApp();
  const [siteOpen, setSiteOpen] = React.useState(false);
  const clock = useClock();
  const sites = HPMD.sites;
  const curSite = siteId === "ALL" ? null : sites.find((s) => s.id === siteId);
  const pad = (n) => String(n).padStart(2, "0");
  const timeStr = `${pad(clock.getHours())}:${pad(clock.getMinutes())}:${pad(clock.getSeconds())}`;
  const ref = React.useRef(null);
  React.useEffect(() => {
    const onClick = (e) => { if (ref.current && !ref.current.contains(e.target)) setSiteOpen(false); };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div className="topbar">
      <div className="brand">
        <div className="logo"><Icons.Logo /></div>
        <div>
          <div style={{ color: "var(--fg-0)", fontWeight: 600, fontSize: 12, letterSpacing: ".02em" }}>HEATPUMP · IIoT</div>
          <div style={{ fontSize: 10, color: "var(--fg-3)" }}>v0.1 · 內部維運後台</div>
        </div>
      </div>

      <div ref={ref} style={{ position: "relative" }}>
        <div className="site-picker" onClick={() => setSiteOpen(!siteOpen)}>
          <Icons.Map />
          <div style={{ flex: 1 }}>
            <div className="lbl">場域</div>
            <div className="val">{curSite ? `${curSite.name} · ${curSite.city}` : "全部場域 · 跨站點"}</div>
          </div>
          <Icons.ChevronD />
        </div>
        {siteOpen && (
          <div style={{
            position: "absolute", top: "calc(100% + 6px)", left: 0,
            width: 320, background: "var(--bg-1)", border: "1px solid var(--line)",
            borderRadius: 10, boxShadow: "var(--shadow-raised)", zIndex: 20, padding: 4,
          }}>
            <div className="site-pick-item" onClick={() => { setSiteId("ALL"); setSiteOpen(false); }}
              style={{ padding: "10px 12px", borderRadius: 6, cursor: "pointer", background: siteId === "ALL" ? "var(--lime-soft)" : "transparent" }}>
              <div style={{ fontSize: 13, color: siteId === "ALL" ? "var(--lime)" : "var(--fg-0)", fontWeight: 500 }}>全部場域</div>
              <div style={{ fontSize: 11, color: "var(--fg-3)", fontFamily: "var(--mono)" }}>{HPMD.devices.length} units · 3 sites</div>
            </div>
            {sites.map((s) => (
              <div key={s.id} onClick={() => { setSiteId(s.id); setSiteOpen(false); }}
                style={{ padding: "10px 12px", borderRadius: 6, cursor: "pointer", background: siteId === s.id ? "var(--lime-soft)" : "transparent" }}
                onMouseEnter={(e) => { if (siteId !== s.id) e.currentTarget.style.background = "var(--bg-2)"; }}
                onMouseLeave={(e) => { if (siteId !== s.id) e.currentTarget.style.background = "transparent"; }}>
                <div style={{ fontSize: 13, color: siteId === s.id ? "var(--lime)" : "var(--fg-0)", fontWeight: 500 }}>{s.name}</div>
                <div style={{ fontSize: 11, color: "var(--fg-3)", fontFamily: "var(--mono)" }}>{s.id} · {s.city} · {s.deviceCount} 台</div>
              </div>
            ))}
          </div>
        )}
      </div>

      <span className="meta-pill"><span className="dot"/>LIVE · {timeStr} GMT+8</span>
      <span className="meta-pill" title="資料同步狀態"><Icons.Refresh size={12} />SYNC · 60s</span>

      <div className="spacer" />

      <div className="role-switch" title="角色切換 (v1 Demo)">
        <button className={role === "operator" ? "on" : ""} onClick={() => setRole("operator")}>
          <Icons.Tool size={12} /> 維運人員
        </button>
        <button className={role === "manager" ? "on" : ""} onClick={() => setRole("manager")}>
          <Icons.Crown size={12} /> 高層管理者
        </button>
      </div>
    </div>
  );
}

// ============================================================
// Side rail — primary nav
// ============================================================
function SideRail() {
  const { page, setPage, role } = useApp();
  const visible = PAGES.filter((p) => p.roles.includes(role));
  return (
    <div className="rail">
      <div className="rail-btn on" style={{ background: "var(--lime)", color: "var(--lime-ink)", marginBottom: 10 }} title="brand">
        <Icons.Logo size={20} />
      </div>
      {visible.map((p) => {
        const Ico = p.icon;
        return (
          <button key={p.id} className={`rail-btn ${page === p.id ? "on" : ""}`} onClick={() => setPage(p.id)}>
            <Ico size={18} />
            <span className="rail-tooltip">{p.label}</span>
          </button>
        );
      })}
      <div className="rail-spacer" />
      <button className="rail-btn" title="系統健康度">
        <Icons.Activity size={18} />
        <span className="rail-tooltip">系統健康度</span>
      </button>
      <button className="rail-btn" title="設定">
        <Icons.Settings size={18} />
        <span className="rail-tooltip">系統設定</span>
      </button>
    </div>
  );
}

// expose
Object.assign(window, { PAGES, AppCtx, AppProvider, useApp, TopBar, SideRail });
