/* global React, HPMD, Icons, StatusPill, RiskBadge, Sparkline, Donut, LineChart,
   useApp, useLiveTick, ago, fmtTime */
// ============================================================
// Page 1 — 設備總覽 Device Overview (P1 MVP)
// ============================================================
function PageOverview() {
  const { siteId, openDevice, alerts } = useApp();
  const tick = useLiveTick(6000);
  const [statusFilter, setStatusFilter] = React.useState("ALL");
  const [viewMode, setViewMode] = React.useState("grid"); // grid | topology | list
  const [search, setSearch] = React.useState("");

  const filteredDevices = React.useMemo(() => {
    let d = HPMD.devices;
    if (siteId !== "ALL") d = d.filter((x) => x.site_id === siteId);
    if (statusFilter !== "ALL") d = d.filter((x) => x.status === statusFilter);
    if (search) d = d.filter((x) => x.name.includes(search) || x.device_id.includes(search));
    return d;
  }, [siteId, statusFilter, search]);

  const counts = React.useMemo(() => {
    const base = HPMD.devices.filter((d) => siteId === "ALL" || d.site_id === siteId);
    const c = { all: base.length, ok: 0, idle: 0, warn: 0, alarm: 0, offline: 0 };
    base.forEach((d) => c[d.status]++);
    return c;
  }, [siteId]);

  const activeAlerts = React.useMemo(() => alerts.filter((a) => a.status !== "resolved" && (siteId === "ALL" || a.site_id === siteId)).slice(0, 6), [alerts, siteId]);

  const totalPower = React.useMemo(() => {
    return filteredDevices.reduce((s, d) => s + (d.status === "ok" || d.status === "warn" || d.status === "alarm" ? d.baseline_power : 0), 0);
  }, [filteredDevices, tick]);
  const avgCop = React.useMemo(() => {
    const live = filteredDevices.filter((d) => d.status === "ok" || d.status === "warn");
    return live.length ? live.reduce((s, d) => s + d.baseline_cop, 0) / live.length : 0;
  }, [filteredDevices]);

  // groups by site
  const grouped = React.useMemo(() => {
    const map = new Map();
    HPMD.sites.forEach((s) => map.set(s.id, { ...s, devices: [] }));
    filteredDevices.forEach((d) => map.get(d.site_id).devices.push(d));
    return Array.from(map.values()).filter((g) => g.devices.length > 0);
  }, [filteredDevices]);

  return (
    <div>
      <div className="page-head">
        <div>
          <div className="num">P1 · OVERVIEW</div>
          <h1>設備總覽</h1>
          <div className="sub">即時掌握 80 台熱泵設備運行狀態 · 跨 3 個場域 · 5 秒推送 / 60 秒批次刷新</div>
        </div>
        <div className="actions">
          <div className="segmented">
            <button className={viewMode === "grid" ? "on" : ""} onClick={() => setViewMode("grid")}>卡片</button>
            <button className={viewMode === "topology" ? "on" : ""} onClick={() => setViewMode("topology")}>拓樸</button>
            <button className={viewMode === "list" ? "on" : ""} onClick={() => setViewMode("list")}>列表</button>
            <button className={viewMode === "3d" ? "on" : ""} onClick={() => setViewMode("3d")}>3D</button>
          </div>
          <button className="btn"><Icons.Refresh size={14} />刷新</button>
        </div>
      </div>

      {/* KPI strip */}
      <div className="grid-4" style={{ marginBottom: 16 }}>
        <KPISummary counts={counts} />
        <KPIBig label="即時功率" value={totalPower.toFixed(1)} unit="kW" trend="▲ 2.4%" icon={<Icons.Bolt />} sparkData={generateSpark(totalPower, 20, 4)} />
        <KPIBig label="平均 COP" value={avgCop.toFixed(2)} unit="W/W" trend="▲ 0.08" icon={<Icons.Activity />} sparkData={generateSpark(avgCop, 20, 0.2)} />
        <KPIBig label="今日累計能耗" value={(filteredDevices.length * 110).toFixed(0)} unit="kWh" trend="▼ 1.1%" trendDown icon={<Icons.Drop />} sparkData={generateSpark(filteredDevices.length * 110, 20, 60)} />
      </div>

      {/* filter row */}
      <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 12, flexWrap: "wrap" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, background: "var(--bg-1)", borderRadius: 8, padding: "0 12px", height: 34, border: "1px solid var(--line-soft)", minWidth: 220 }}>
          <Icons.Search size={14} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="搜尋設備名稱或編號" style={{ background: "transparent", border: 0, color: "var(--fg-0)", fontSize: 12, flex: 1, outline: "none" }} />
        </div>
        <StatusChip cur={statusFilter} set={setStatusFilter} id="ALL"     label="全部"   n={counts.all} />
        <StatusChip cur={statusFilter} set={setStatusFilter} id="ok"      label="正常"   n={counts.ok}     color="var(--ok)" />
        <StatusChip cur={statusFilter} set={setStatusFilter} id="warn"    label="警告"   n={counts.warn}   color="var(--warn)" />
        <StatusChip cur={statusFilter} set={setStatusFilter} id="alarm"   label="異常"   n={counts.alarm}  color="var(--alarm)" />
        <StatusChip cur={statusFilter} set={setStatusFilter} id="idle"    label="待機"   n={counts.idle}   color="var(--info)" />
        <StatusChip cur={statusFilter} set={setStatusFilter} id="offline" label="離線"   n={counts.offline} color="var(--stale)" />
        <div className="spacer" style={{ flex: 1 }} />
        <span className="eyebrow">顯示 {filteredDevices.length} / {HPMD.devices.length} 台</span>
      </div>

      <div className="grid-12">
        {/* main panel */}
        <div style={{ gridColumn: "span 9", display: "flex", flexDirection: "column", gap: 16 }}>
          {viewMode === "grid" && (
            <DeviceGrid grouped={grouped} onOpen={openDevice} tick={tick} />
          )}
          {viewMode === "topology" && (
            <TopologyView grouped={grouped} onOpen={openDevice} tick={tick} />
          )}
          {viewMode === "list" && (
            <DeviceList devices={filteredDevices} onOpen={openDevice} tick={tick} />
          )}
          {viewMode === "3d" && (
            <Iso3DView devices={filteredDevices} onOpen={openDevice} tick={tick} />
          )}
        </div>

        {/* sidebar */}
        <div style={{ gridColumn: "span 3", display: "flex", flexDirection: "column", gap: 16 }}>
          <RecentAlerts list={activeAlerts} />
          <SiteRollup />
          <DataQuality />
        </div>
      </div>
    </div>
  );
}

// ============================================================
// KPI strip cards
// ============================================================
function KPIBig({ label, value, unit, trend, trendDown, icon, sparkData }) {
  return (
    <div className="kpi-card">
      <div className="head">
        <span className="ic">{icon}</span>
        {label}
      </div>
      <div className="val val-num">{value}<span className="u">{unit}</span></div>
      <div className={`trend ${trendDown ? "down" : ""}`}>{trend} <span className="dimmer">vs 昨日</span></div>
      <div className="spark"><Sparkline data={sparkData} width={80} height={28} /></div>
    </div>
  );
}

function KPISummary({ counts }) {
  const total = counts.all;
  const slices = [
    { value: counts.ok,      color: "var(--ok)" },
    { value: counts.warn,    color: "var(--warn)" },
    { value: counts.alarm,   color: "var(--alarm)" },
    { value: counts.idle,    color: "var(--info)" },
    { value: counts.offline, color: "var(--stale)" },
  ];
  return (
    <div className="kpi-card" style={{ flexDirection: "row", alignItems: "center", gap: 14, padding: "10px 14px" }}>
      <Donut size={86} stroke={11} slices={slices} center={{ value: total, label: "TOTAL" }} />
      <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", rowGap: 4, columnGap: 8, flex: 1, fontSize: 11, alignSelf: "center" }}>
        <Row color="var(--ok)"    label="正常" n={counts.ok} />
        <Row color="var(--warn)"  label="警告" n={counts.warn} />
        <Row color="var(--alarm)" label="異常" n={counts.alarm} />
        <Row color="var(--info)"  label="待機" n={counts.idle} />
        <Row color="var(--stale)" label="離線" n={counts.offline} />
      </div>
    </div>
  );
}
function Row({ color, label, n }) {
  return (<>
    <span style={{ width: 6, height: 6, borderRadius: "50%", background: color, alignSelf: "center" }} />
    <span style={{ color: "var(--fg-2)" }}>{label}</span>
    <span className="val-num" style={{ color: "var(--fg-0)" }}>{n}</span>
  </>);
}

// ============================================================
// status chip
// ============================================================
function StatusChip({ cur, set, id, label, n, color }) {
  return (
    <div className={`chip ${cur === id ? "on" : ""}`} onClick={() => set(id)}>
      {color && <span style={{ width: 6, height: 6, borderRadius: "50%", background: color }} />}
      <span>{label}</span>
      <span className="dimmer mono" style={{ fontSize: 10 }}>{n}</span>
    </div>
  );
}

// ============================================================
// Device grid (cards by site)
// ============================================================
function DeviceGrid({ grouped, onOpen, tick }) {
  return (
    <>
      {grouped.map((g) => (
        <SiteGroup key={g.id} site={g} onOpen={onOpen} tick={tick} />
      ))}
      {grouped.length === 0 && (
        <div className="card center" style={{ padding: 60 }}>
          <div className="dimmer">沒有符合條件的設備</div>
        </div>
      )}
    </>
  );
}

function SiteGroup({ site, onOpen, tick }) {
  const counts = { ok: 0, warn: 0, alarm: 0, offline: 0, idle: 0 };
  site.devices.forEach((d) => counts[d.status]++);
  return (
    <div className="card">
      <div className="card-head">
        <div className="ic"><Icons.Map size={14} /></div>
        <h4>{site.name}</h4>
        <span className="sub">{site.id} · {site.city} · {site.kind}</span>
        <div style={{ display: "flex", gap: 6, marginLeft: "auto" }}>
          {counts.alarm > 0 && <span className="pill alarm"><span className="d"/>{counts.alarm} 異常</span>}
          {counts.warn > 0 && <span className="pill warn"><span className="d"/>{counts.warn} 警告</span>}
          {counts.offline > 0 && <span className="pill stale"><span className="d"/>{counts.offline} 離線</span>}
          <span className="pill ok"><span className="d"/>{counts.ok} 運行中</span>
        </div>
      </div>
      <div className="card-body">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(184px, 1fr))", gap: 10 }}>
          {site.devices.map((d) => <DeviceTile key={d.device_id} d={d} onOpen={onOpen} tick={tick} />)}
        </div>
      </div>
    </div>
  );
}

function DeviceTile({ d, onOpen, tick }) {
  const r = HPMD.readingsFor(d, Date.now() + tick * 6000);
  const lastUpdate = d.status === "offline" ? `${5 + (tick % 7)}m 前` : `${(tick % 12) + 1}s 前`;
  return (
    <div className={`tile s-${d.status}`} onClick={() => onOpen(d.device_id)}>
      <span className="ind" />
      <div className="top">
        <div>
          <div className="id">{d.device_id}</div>
          <div className="name">{d.name}</div>
        </div>
      </div>
      {r ? (
        <>
          <div className="row"><span>T_out</span><b>{r.temp_outlet.toFixed(1)} °C</b></div>
          <div className="row"><span>Power</span><b>{r.power_kw.toFixed(1)} kW</b></div>
          <div className="row"><span>COP</span><b>{r.cop.toFixed(2)}</b></div>
        </>
      ) : (
        <>
          <div className="row"><span>T_out</span><b className="dimmer">—</b></div>
          <div className="row"><span>Power</span><b className="dimmer">—</b></div>
          <div className="row"><span>COP</span><b className="dimmer">—</b></div>
        </>
      )}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 4 }}>
        <StatusPill status={d.status} dim />
        <span style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--fg-3)" }}>{lastUpdate}</span>
      </div>
    </div>
  );
}

// ============================================================
// Device list
// ============================================================
function DeviceList({ devices, onOpen, tick }) {
  return (
    <div className="card">
      <div className="card-body" style={{ padding: 0 }}>
        <div style={{ overflowX: "auto" }}>
          <table className="dt">
            <thead>
              <tr>
                <th>狀態</th>
                <th>編號</th>
                <th>名稱</th>
                <th>場域</th>
                <th>風險</th>
                <th style={{ textAlign: "right" }}>T_out</th>
                <th style={{ textAlign: "right" }}>P_high</th>
                <th style={{ textAlign: "right" }}>Power</th>
                <th style={{ textAlign: "right" }}>COP</th>
                <th style={{ textAlign: "right" }}>累計運轉</th>
                <th>最後更新</th>
              </tr>
            </thead>
            <tbody>
              {devices.slice(0, 60).map((d) => {
                const r = HPMD.readingsFor(d, Date.now() + tick * 6000);
                return (
                  <tr key={d.device_id} onClick={() => onOpen(d.device_id)}>
                    <td><StatusPill status={d.status} dim /></td>
                    <td className="mono dim">{d.device_id}</td>
                    <td>{d.name}</td>
                    <td className="dim">{d.site_name}</td>
                    <td><RiskBadge level={d.risk_level} /></td>
                    <td className="num">{r ? r.temp_outlet.toFixed(1) : "—"}</td>
                    <td className="num">{r ? r.pressure_high.toFixed(1) : "—"}</td>
                    <td className="num">{r ? r.power_kw.toFixed(1) : "—"}</td>
                    <td className="num">{r ? r.cop.toFixed(2) : "—"}</td>
                    <td className="num">{d.runtime_h.toLocaleString()} h</td>
                    <td className="mono dim" style={{ fontSize: 11 }}>{d.status === "offline" ? "5m+ ago" : "just now"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {devices.length > 60 && (
          <div style={{ padding: 12, textAlign: "center", color: "var(--fg-3)", fontSize: 11 }}>
            顯示前 60 筆 · 共 {devices.length} 筆 · 套用篩選縮小範圍
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================
// Topology view — schematic diagram with bank rows
// ============================================================
function TopologyView({ grouped, onOpen, tick }) {
  // Show first site's devices as topology if a site is selected; else show one bank per site
  return (
    <div className="card">
      <div className="card-head">
        <div className="ic"><Icons.Compress size={14} /></div>
        <h4>系統流程圖</h4>
        <span className="sub">蒸發器 → 壓縮機 → 冷凝器 → 緩衝水箱</span>
      </div>
      <div className="card-body" style={{ padding: 0 }}>
        <div className="topology">
          <div style={{ display: "grid", gridTemplateColumns: "120px repeat(4, 1fr)", gap: 12, marginBottom: 8 }}>
            <div className="eyebrow"></div>
            {["Stage 01 · 蒸發器", "Stage 02 · 壓縮機", "Stage 03 · 冷凝器", "Stage 04 · 緩衝水箱"].map((l) => (
              <div key={l} style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--fg-3)", textTransform: "uppercase", letterSpacing: ".08em", padding: "0 8px" }}>{l}</div>
            ))}
          </div>

          {grouped.slice(0, 3).map((site) => (
            <div key={site.id} style={{ marginBottom: 16 }}>
              <div style={{ display: "grid", gridTemplateColumns: "120px repeat(4, 1fr)", gap: 12, alignItems: "stretch" }}>
                <div style={{ padding: "8px 12px", background: "var(--bg-2)", borderRadius: 8, fontSize: 11 }}>
                  <div style={{ fontFamily: "var(--mono)", color: "var(--fg-3)", fontSize: 10 }}>{site.id}</div>
                  <div style={{ color: "var(--fg-0)", fontWeight: 500, marginTop: 2 }}>{site.name}</div>
                  <div style={{ color: "var(--fg-3)", fontSize: 10 }}>{site.devices.length} 台 / {site.city}</div>
                </div>
                {site.devices.slice(0, 4).map((d, idx) => (
                  <TopoNode key={d.device_id} d={d} stage={idx} onOpen={onOpen} tick={tick} />
                ))}
              </div>
              {/* connector pipes */}
              <div style={{ position: "relative", height: 12, marginTop: -2 }}>
                <svg width="100%" height="12" preserveAspectRatio="none" style={{ position: "absolute", left: 0 }}>
                  <line x1="20%" y1="2" x2="40%" y2="2" stroke="var(--lime)" strokeWidth="1" opacity="0.4" strokeDasharray="2 4" />
                  <line x1="42%" y1="2" x2="62%" y2="2" stroke="var(--lime)" strokeWidth="1" opacity="0.4" strokeDasharray="2 4" />
                  <line x1="64%" y1="2" x2="84%" y2="2" stroke="var(--lime)" strokeWidth="1" opacity="0.4" strokeDasharray="2 4" />
                </svg>
              </div>
            </div>
          ))}
          <div className="dimmer" style={{ fontSize: 11, marginTop: 12, fontFamily: "var(--mono)" }}>
            * 拓樸圖以場域為單位，每場域展示前 4 台設備之邏輯流。完整列表請切換至列表檢視。
          </div>
        </div>
      </div>
    </div>
  );
}

function TopoNode({ d, stage, onOpen, tick }) {
  const r = HPMD.readingsFor(d, Date.now() + tick * 6000);
  const labels = ["EV · 蒸發器", "CP · 壓縮機", "CN · 冷凝器", "BT · 緩衝水箱"];
  const metrics = (() => {
    if (!r) return [["—", "—"], ["—", "—"]];
    switch (stage) {
      case 0: return [["T_air", `${r.temp_ambient.toFixed(1)} °C`], ["Fan", `${(r.compressor_hz > 0 ? 72 : 0)} %`]];
      case 1: return [["P_dis", `${r.pressure_high.toFixed(1)} bar`], ["Hz", String(r.compressor_hz)]];
      case 2: return [["T_out", `${r.temp_outlet.toFixed(1)} °C`], ["ΔT", `+${(r.temp_outlet - r.temp_inlet).toFixed(1)} °C`]];
      case 3: return [["T_tank", `${(r.temp_outlet - 2).toFixed(1)} °C`], ["SoC", "84 %"]];
    }
  })();
  return (
    <div className={`tile s-${d.status}`} style={{ minHeight: 96 }} onClick={() => onOpen(d.device_id)}>
      <span className="ind" />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div className="id">{labels[stage]}</div>
        <span className="mono" style={{ fontSize: 10, color: "var(--fg-3)" }}>{d.device_id.slice(-3)}</span>
      </div>
      {metrics.map(([k, v]) => (
        <div key={k} className="row"><span>{k}</span><b>{v}</b></div>
      ))}
    </div>
  );
}

// ============================================================
// Right column
// ============================================================
function RecentAlerts({ list }) {
  const { setPage } = useApp();
  return (
    <div className="card">
      <div className="card-head">
        <div className="ic"><Icons.Alarm size={14} /></div>
        <h4>未處理告警</h4>
        <span className="sub">{list.length} 筆</span>
      </div>
      <div className="card-body" style={{ padding: 4 }}>
        {list.length === 0 && (
          <div style={{ padding: 24, textAlign: "center", color: "var(--fg-3)", fontSize: 12 }}>
            <Icons.Check size={20} /><br/>所有告警均已處理
          </div>
        )}
        {list.map((a) => (
          <div key={a.id} style={{ padding: "10px 12px", borderRadius: 6, marginBottom: 2, cursor: "pointer" }}
            onMouseEnter={(e) => e.currentTarget.style.background = "var(--bg-2)"}
            onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
            onClick={() => setPage("alerts")}>
            <div style={{ display: "flex", gap: 8, alignItems: "flex-start", justifyContent: "space-between" }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, color: "var(--fg-0)", fontWeight: 500 }}>{a.label}</div>
                <div className="dim" style={{ fontSize: 11, marginTop: 2 }}>{a.device_name} · {a.site_name}</div>
              </div>
              <span className={`pill ${a.severity === "critical" ? "alarm" : a.severity === "warning" ? "warn" : "info"}`} style={{ height: 18, fontSize: 9 }}>
                <span className="d" />
              </span>
            </div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--fg-3)", marginTop: 4 }}>觸發於 {ago(a.triggered_at)} 前</div>
          </div>
        ))}
        {list.length > 0 && (
          <button className="btn ghost" style={{ width: "100%", marginTop: 4 }} onClick={() => setPage("alerts")}>
            全部告警 <Icons.ChevronR size={12} />
          </button>
        )}
      </div>
    </div>
  );
}

function SiteRollup() {
  const summary = HPMD.sitesSummary();
  const { setSiteId } = useApp();
  return (
    <div className="card">
      <div className="card-head">
        <div className="ic"><Icons.Map size={14} /></div>
        <h4>場域概況</h4>
      </div>
      <div className="card-body" style={{ padding: 8 }}>
        {summary.map((s) => {
          const healthPct = Math.round((s.counts.ok / s.devices.length) * 100);
          return (
            <div key={s.id} style={{ padding: 10, borderRadius: 6, cursor: "pointer" }}
              onMouseEnter={(e) => e.currentTarget.style.background = "var(--bg-2)"}
              onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
              onClick={() => setSiteId(s.id)}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                <div style={{ fontSize: 12, color: "var(--fg-0)", fontWeight: 500 }}>{s.name}</div>
                <span className="val-num" style={{ fontSize: 14, color: healthPct > 90 ? "var(--ok)" : healthPct > 70 ? "var(--warn)" : "var(--alarm)" }}>{healthPct}%</span>
              </div>
              <div className="risk-bar" style={{ marginTop: 6, marginBottom: 4 }}>
                <div className="fill" style={{ width: `${healthPct}%`, background: healthPct > 90 ? "var(--ok)" : healthPct > 70 ? "var(--warn)" : "var(--alarm)" }} />
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "var(--fg-3)", fontFamily: "var(--mono)" }}>
                <span>{s.devices.length} 台 · {s.alerts_active} 告警</span>
                <span>{s.total_power.toFixed(0)} kW</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DataQuality() {
  return (
    <div className="card">
      <div className="card-head">
        <div className="ic"><Icons.Info size={14} /></div>
        <h4>資料品質</h4>
      </div>
      <div className="card-body" style={{ fontSize: 11, color: "var(--fg-2)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span>真實資料源</span>
          <span className="val-num"><span className="pill ok"><span className="d"/>3 台</span></span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span>模擬資料源</span>
          <span className="val-num dim">77 台</span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span>InfluxDB · 1.8</span>
          <span className="val-num"><span className="pill ok"><span className="d"/>OK</span></span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span>MySQL · 8.0</span>
          <span className="val-num"><span className="pill ok"><span className="d"/>OK</span></span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span>Node-RED</span>
          <span className="val-num"><span className="pill ok"><span className="d"/>12ms</span></span>
        </div>
      </div>
    </div>
  );
}

// helper: deterministic sparkline data
function generateSpark(baseVal, n, jitter) {
  const out = [];
  let v = baseVal * 0.9;
  for (let i = 0; i < n; i++) {
    v += (Math.sin(i / 2.3) + (Math.random() - 0.5) * 0.6) * jitter * 0.3;
    out.push(v);
  }
  return out;
}

// ============================================================
// 3D Isometric view — max 9 tiles per page, with pagination
// ============================================================
function Iso3DView({ devices, onOpen, tick }) {
  const [page, setPage] = React.useState(0);
  const [selected, setSelected] = React.useState(null);
  const perPage = 9;
  const totalPages = Math.max(1, Math.ceil(devices.length / perPage));
  // clamp page when filter changes
  React.useEffect(() => {
    if (page >= totalPages) setPage(0);
    setSelected(null);
  }, [devices, totalPages]);

  const slice = devices.slice(page * perPage, page * perPage + perPage);
  // pad with empties to keep 3x3 grid shape
  while (slice.length < perPage) slice.push(null);

  const selectedDevice = selected ? devices.find((d) => d && d.device_id === selected) : null;

  return (
    <div className="card iso-card">
      <div className="card-head">
        <div className="ic"><Icons.Compress size={14} /></div>
        <h4>3D 等距檢視</h4>
        <span className="sub">最多顯示 9 台 · 點選查看詳細數據</span>
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 10 }}>
          <button className="btn btn-icon" disabled={page === 0} onClick={() => setPage((p) => Math.max(0, p - 1))}>
            <Icons.ChevronR size={14} style={{ transform: "rotate(180deg)" }} />
          </button>
          <div className="mono" style={{ fontSize: 12, color: "var(--fg-1)", minWidth: 80, textAlign: "center" }}>
            <span style={{ color: "var(--lime)" }}>{String(page + 1).padStart(2, "0")}</span>
            <span style={{ color: "var(--fg-3)" }}> / {String(totalPages).padStart(2, "0")}</span>
            <div style={{ fontSize: 10, color: "var(--fg-3)" }}>
              第 {page * perPage + 1} – {Math.min((page + 1) * perPage, devices.length)} 台
            </div>
          </div>
          <button className="btn btn-icon" disabled={page >= totalPages - 1} onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}>
            <Icons.ChevronR size={14} />
          </button>
        </div>
      </div>

      <div className="iso-stage">
        {/* sky/horizon glow */}
        <div className="iso-horizon" />
        <div className="iso-wrap">
          <div className="iso-grid">
            {slice.map((d, i) => {
              const row = Math.floor(i / 3);
              const col = i % 3;
              if (!d) return <div key={`empty-${i}`} className="iso-cell iso-empty" data-row={row} data-col={col} />;
              const r = HPMD.readingsFor(d, Date.now() + tick * 6000);
              return (
                <Iso3DTile
                  key={d.device_id}
                  d={d}
                  r={r}
                  selected={selected === d.device_id}
                  onClick={() => setSelected(selected === d.device_id ? null : d.device_id)}
                  onOpen={() => onOpen(d.device_id)}
                  row={row}
                  col={col}
                />
              );
            })}
          </div>
        </div>

        {/* legend */}
        <div className="iso-legend">
          <span><i style={{ background: "var(--ok)" }} />正常</span>
          <span><i style={{ background: "var(--warn)" }} />警告</span>
          <span><i style={{ background: "var(--alarm)" }} />異常</span>
          <span><i style={{ background: "var(--info)" }} />待機</span>
          <span><i style={{ background: "var(--stale)" }} />離線</span>
        </div>

        {/* page dots */}
        {totalPages > 1 && (
          <div className="iso-dots">
            {Array.from({ length: Math.min(totalPages, 12) }, (_, i) => (
              <button key={i} className={`iso-dot ${page === i ? "on" : ""}`} onClick={() => setPage(i)} />
            ))}
            {totalPages > 12 && <span className="dimmer mono" style={{ fontSize: 10 }}>+{totalPages - 12}</span>}
          </div>
        )}
      </div>

      {/* detail strip */}
      {selectedDevice && <Iso3DDetail device={selectedDevice} tick={tick} onOpen={() => onOpen(selectedDevice.device_id)} onClose={() => setSelected(null)} />}
    </div>
  );
}

function Iso3DTile({ d, r, selected, onClick, onOpen, row, col }) {
  const ind = d.is_mock ? "M" : "R";
  return (
    <div
      className={`iso-cell iso-tile s-${d.status} ${selected ? "selected" : ""}`}
      onClick={onClick}
      onDoubleClick={onOpen}
      data-row={row}
      data-col={col}
    >
      {/* flat plate (floor) */}
      <div className="iso-plate">
        <div className="iso-plate-pattern" />
        <span className="iso-label">{d.device_id.slice(-7)}</span>
        <span className="iso-flag" />
      </div>

      {/* machine 3D-ish */}
      <div className="iso-machine">
        <div className="iso-base" />
        <div className="iso-housing">
          <div className="iso-housing-front" />
          <div className="iso-housing-side" />
          <div className="iso-housing-top">
            <span className="iso-fan" />
          </div>
        </div>
        <div className="iso-stack" />
      </div>

      {/* hover ring */}
      <div className="iso-ring" />
    </div>
  );
}

function Iso3DDetail({ device, tick, onOpen, onClose }) {
  const r = HPMD.readingsFor(device, Date.now() + tick * 6000);
  return (
    <div className="iso-detail">
      <div className="iso-detail-head">
        <span className={`iso-detail-tag s-${device.status}`}>
          <span className="d" />
          {window.STATUS[device.status].label}
        </span>
        <div>
          <div className="iso-detail-title">{device.name}</div>
          <div className="mono dimmer" style={{ fontSize: 11 }}>{device.device_id} · {device.model} · {device.site_name}</div>
        </div>
        <div style={{ flex: 1 }} />
        <button className="btn" onClick={onOpen}>查看履歷 <Icons.ChevronR size={12} /></button>
        <button className="btn btn-icon ghost" onClick={onClose}><Icons.X size={12} /></button>
      </div>
      <div className="iso-detail-rows">
        {r ? [
          ["出水溫度", `${r.temp_outlet.toFixed(1)} °C`, device.status === "alarm"],
          ["回水溫度", `${r.temp_inlet.toFixed(1)} °C`, false],
          ["高壓壓力", `${r.pressure_high.toFixed(1)} bar`, false],
          ["即時功率", `${r.power_kw.toFixed(1)} kW`, false],
          ["COP",     r.cop.toFixed(2), false],
          ["壓縮機 Hz", String(r.compressor_hz), false],
          ["循環流量", r.flow_lpm > 0 ? `${r.flow_lpm.toFixed(0)} L/min` : "LOW", r.flow_lpm === 0],
          ["累計運轉", `${(device.runtime_h / 1000).toFixed(1)}k h`, false],
        ].map(([k, v, alert]) => (
          <div key={k} className="iso-detail-row">
            <span className="dim">{k}</span>
            <span className="val-num" style={{ color: alert ? "var(--alarm)" : "var(--fg-0)" }}>{v}</span>
          </div>
        )) : (
          <div className="iso-detail-row" style={{ gridColumn: "1 / -1", color: "var(--fg-3)", textAlign: "center", padding: 14 }}>
            設備離線中 · 無法取得即時數據
          </div>
        )}
      </div>
    </div>
  );
}

window.PageOverview = PageOverview;
