/* global React, HPMD, Icons, StatusPill, RiskBadge, Sparkline, LineChart, SeverityPill,
   useApp, useLiveTick, ago, fmtTime */
// ============================================================
// Page 3 — 單機履歷 Single Device History (P3)
// ============================================================
function PageDevice() {
  const { activeDeviceId, openDevice, alerts } = useApp();
  const tick = useLiveTick(6000);
  const [range, setRange] = React.useState("24h");
  const [tab, setTab] = React.useState("trend"); // trend | alerts | maintenance

  // pick a device with rich data if none selected
  const device = React.useMemo(() => {
    if (activeDeviceId) return HPMD.devices.find((d) => d.device_id === activeDeviceId);
    return HPMD.devices.find((d) => d.device_id === "SITE01-001");
  }, [activeDeviceId]);

  if (!device) return null;

  if (!device._trends) device._trends = HPMD.buildTrends(device);
  const trends = device._trends;
  const r = HPMD.readingsFor(device, Date.now() + tick * 6000);
  const deviceAlerts = alerts.filter((a) => a.device_id === device.device_id);
  const deviceMaint = HPMD.maintenance.filter((m) => m.device_id === device.device_id);

  // build trend slice based on range
  const slice = (data) => {
    if (range === "1h") return data.slice(-12);
    if (range === "6h") return data.slice(-72);
    if (range === "24h") return data;
    if (range === "7d") {
      // synthesize 7d by repeating with drift
      const arr = [];
      for (let day = 0; day < 7; day++) {
        const d = data.filter((_, i) => i % 12 === 0).map((v, i) => v + Math.sin(day + i) * 1.2);
        arr.push(...d);
      }
      return arr;
    }
    return data;
  };

  return (
    <div>
      <div className="page-head">
        <div>
          <div className="num">P3 · DEVICE HISTORY</div>
          <h1>單機履歷</h1>
          <div className="sub">運轉趨勢、告警歷史、保養紀錄全紀錄</div>
        </div>
        <div className="actions">
          <DevicePicker current={device} onPick={openDevice} />
          <button className="btn"><Icons.Download size={14} />匯出</button>
        </div>
      </div>

      {/* device header */}
      <DeviceHeader device={device} r={r} />

      {/* tabs */}
      <div style={{ display: "flex", alignItems: "center", marginTop: 16, marginBottom: 12, borderBottom: "1px solid var(--line-soft)" }}>
        <Tab cur={tab} set={setTab} id="trend" label="趨勢分析" />
        <Tab cur={tab} set={setTab} id="alerts" label={`告警歷史 (${deviceAlerts.length})`} />
        <Tab cur={tab} set={setTab} id="maintenance" label={`保養紀錄 (${deviceMaint.length})`} />
        <div style={{ flex: 1 }} />
        {tab === "trend" && (
          <div className="segmented">
            {["1h", "6h", "24h", "7d", "30d"].map((rg) => (
              <button key={rg} className={range === rg ? "on" : ""} onClick={() => setRange(rg)}>{rg}</button>
            ))}
          </div>
        )}
      </div>

      {/* tab content */}
      {tab === "trend" && (
        <div className="grid-2" style={{ marginBottom: 16 }}>
          <TrendCard title="出水溫度" unit="°C" data={slice(trends.temp_outlet)} range={range} threshold={{ warn: device.rated_outlet_t + 3, crit: device.rated_outlet_t + 6 }} color="var(--t-4)" />
          <TrendCard title="即時功率" unit="kW" data={slice(trends.power_kw)} range={range} color="var(--lime)" />
          <TrendCard title="COP 效率" unit="W/W" data={slice(trends.cop)} range={range} threshold={{ warn: 2.5, crit: 2 }} color="var(--info)" reverseThreshold />
          <TrendCard title="高壓壓力" unit="bar" data={slice(trends.pressure_high)} range={range} threshold={{ warn: 24, crit: 27 }} color="var(--warn)" />
        </div>
      )}

      {tab === "alerts" && <AlertsHistory list={deviceAlerts} />}
      {tab === "maintenance" && <MaintenanceHistory list={deviceMaint} device={device} />}

      {/* footer info */}
      {tab === "trend" && <SpecsAndCorrelation device={device} trends={trends} />}
    </div>
  );
}

function Tab({ cur, set, id, label }) {
  return (
    <button onClick={() => set(id)}
      style={{
        background: "transparent", border: 0, padding: "10px 14px",
        color: cur === id ? "var(--fg-0)" : "var(--fg-2)",
        fontFamily: "var(--sans)", fontSize: 13, fontWeight: 500,
        borderBottom: `2px solid ${cur === id ? "var(--lime)" : "transparent"}`,
        cursor: "pointer", marginBottom: -1,
      }}>{label}</button>
  );
}

function DevicePicker({ current, onPick }) {
  const [open, setOpen] = React.useState(false);
  const [search, setSearch] = React.useState("");
  const list = React.useMemo(() => HPMD.devices.filter((d) => !search || d.name.includes(search) || d.device_id.includes(search)), [search]);
  return (
    <div style={{ position: "relative" }}>
      <button className="btn" onClick={() => setOpen(!open)} style={{ minWidth: 220 }}>
        <Icons.Grid size={14} />
        <span style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--fg-3)" }}>{current.device_id}</span>
        <span style={{ color: "var(--fg-0)" }}>{current.name}</span>
        <Icons.ChevronD size={14} />
      </button>
      {open && (
        <div style={{ position: "absolute", top: "calc(100% + 4px)", right: 0, width: 340, background: "var(--bg-1)", border: "1px solid var(--line)", borderRadius: 10, boxShadow: "var(--shadow-raised)", zIndex: 20, maxHeight: 400, display: "flex", flexDirection: "column" }}>
          <div style={{ padding: 10, borderBottom: "1px solid var(--line-soft)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <Icons.Search size={14} />
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="搜尋..." style={{ background: "transparent", border: 0, color: "var(--fg-0)", fontSize: 12, flex: 1, outline: "none" }} />
            </div>
          </div>
          <div style={{ overflowY: "auto", flex: 1, padding: 4 }}>
            {list.slice(0, 30).map((d) => (
              <div key={d.device_id} onClick={() => { onPick(d.device_id); setOpen(false); }}
                style={{ padding: "8px 12px", borderRadius: 6, cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }}
                onMouseEnter={(e) => e.currentTarget.style.background = "var(--bg-2)"}
                onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}>
                <StatusPill status={d.status} dim />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12, color: "var(--fg-0)" }}>{d.name}</div>
                  <div className="mono dimmer" style={{ fontSize: 10 }}>{d.device_id}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function DeviceHeader({ device, r }) {
  return (
    <div className="card" style={{ padding: 0 }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr auto", padding: "16px 20px", borderBottom: "1px solid var(--line-soft)", alignItems: "center", gap: 16 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div className={`tile s-${device.status}`} style={{ width: 56, height: 56, padding: 0, display: "grid", placeItems: "center" }}>
            <Icons.Compress size={24} />
          </div>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <h2 style={{ margin: 0, fontSize: 22, fontWeight: 600 }}>{device.name}</h2>
              <StatusPill status={device.status} />
              <RiskBadge level={device.risk_level} />
            </div>
            <div className="mono dimmer" style={{ marginTop: 4, fontSize: 11 }}>
              {device.device_id} · {device.model} · {device.site_name} · 裝機 {device.installed_at}
              {device.is_mock && <span style={{ marginLeft: 8, color: "var(--warn)" }}>· 模擬資料</span>}
            </div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn"><Icons.Calendar size={14} />排程保養</button>
          <button className="btn primary"><Icons.Alarm size={14} />建立告警</button>
        </div>
      </div>

      {/* live metrics */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 0 }}>
        {[
          ["出水溫度", "T_out", r ? `${r.temp_outlet.toFixed(1)}` : "—", "°C", "var(--t-4)"],
          ["回水溫度", "T_in",  r ? `${r.temp_inlet.toFixed(1)}` : "—",  "°C", "var(--t-1)"],
          ["環境溫度", "T_amb", r ? `${r.temp_ambient.toFixed(1)}` : "—", "°C", "var(--info)"],
          ["即時功率", "kW",    r ? `${r.power_kw.toFixed(1)}` : "—",  "kW", "var(--lime)"],
          ["COP",     "W/W",   r ? `${r.cop.toFixed(2)}` : "—",       "",   "var(--ok)"],
          ["累計運轉", "h",     device.runtime_h.toLocaleString(),     "h",  "var(--fg-1)"],
        ].map(([lbl, code, val, unit, color], i) => (
          <div key={i} style={{ padding: "14px 16px", borderRight: i < 5 ? "1px solid var(--line-soft)" : "none" }}>
            <div className="eyebrow" style={{ display: "flex", justifyContent: "space-between" }}>
              <span>{lbl}</span>
              <span style={{ color: "var(--fg-3)" }}>{code}</span>
            </div>
            <div className="val-num" style={{ fontSize: 24, color, fontWeight: 500, marginTop: 4 }}>{val}<span style={{ fontSize: 12, color: "var(--fg-3)", marginLeft: 3 }}>{unit}</span></div>
          </div>
        ))}
      </div>
    </div>
  );
}

function TrendCard({ title, unit, data, range, threshold, color, reverseThreshold }) {
  const n = data.length;
  const labels = range === "7d"
    ? ["Day-7", "Day-6", "Day-5", "Day-4", "Day-3", "Day-2", "Today"]
    : range === "1h"
      ? ["−60m", "−45m", "−30m", "−15m", "Now"]
      : ["−24h", "−18h", "−12h", "−6h", "Now"];
  const series = [{ data, color, area: true }];
  const lo = Math.min(...data, threshold ? threshold.warn - 2 : Infinity);
  const hi = Math.max(...data, threshold ? threshold.crit + 2 : -Infinity);
  return (
    <div className="card">
      <div className="card-head">
        <h4>{title}</h4>
        <span className="sub">{unit}</span>
        <span className="val-num" style={{ marginLeft: "auto", color }}>{data[data.length - 1].toFixed(2)}</span>
      </div>
      <div className="card-body" style={{ paddingTop: 8 }}>
        <LineChart series={series} width={520} height={180} xLabels={labels} threshold={threshold} yRange={[lo, hi]} />
        {threshold && (
          <div style={{ display: "flex", gap: 12, fontSize: 10, fontFamily: "var(--mono)", color: "var(--fg-3)", marginTop: 6 }}>
            <span>— warn {threshold.warn}{reverseThreshold ? " ↓" : " ↑"}</span>
            <span>— critical {threshold.crit}{reverseThreshold ? " ↓" : " ↑"}</span>
            <span style={{ marginLeft: "auto" }}>{n} 點資料 · {range}</span>
          </div>
        )}
      </div>
    </div>
  );
}

function AlertsHistory({ list }) {
  if (list.length === 0) {
    return <div className="card center" style={{ padding: 80 }}>
      <div className="empty-state">
        <div className="ic"><Icons.Check size={32} /></div>
        <h4>此期間無告警紀錄</h4>
        <div className="dimmer">設備運行表現良好。</div>
      </div>
    </div>;
  }
  return (
    <div className="card">
      <div className="card-body" style={{ padding: 0 }}>
        <table className="dt">
          <thead>
            <tr><th>嚴重度</th><th>類型</th><th>觸發時間</th><th>確認時間</th><th>解決時間</th><th>處理備註</th><th>狀態</th></tr>
          </thead>
          <tbody>
            {list.map((a) => (
              <tr key={a.id} style={{ cursor: "default" }}>
                <td><SeverityPill severity={a.severity} /></td>
                <td>{a.label} <span className="mono dimmer" style={{ fontSize: 10 }}>{a.code}</span></td>
                <td className="mono dim">{fmtTime(a.triggered_at)}</td>
                <td className="mono dim">{a.acknowledged_at ? fmtTime(a.acknowledged_at) : "—"}</td>
                <td className="mono dim">{a.resolved_at ? fmtTime(a.resolved_at) : "—"}</td>
                <td style={{ color: "var(--fg-2)", fontSize: 11 }}>{a.note || "—"}</td>
                <td>
                  <span className={`pill ${a.status === "resolved" ? "ok" : a.status === "acknowledged" ? "warn" : "alarm"}`}>
                    <span className="d" />
                    {a.status === "resolved" ? "已解決" : a.status === "acknowledged" ? "已確認" : "未處理"}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function MaintenanceHistory({ list, device }) {
  return (
    <div className="card">
      <div className="card-head">
        <h4>保養紀錄</h4>
        <span className="sub">最後保養 {device.last_service}</span>
        <button className="btn primary" style={{ marginLeft: "auto" }}><Icons.Plus size={14} />新增紀錄</button>
      </div>
      <div className="card-body" style={{ padding: 0 }}>
        {list.length === 0 ? (
          <div className="empty-state" style={{ padding: 40 }}>
            <div className="ic"><Icons.Tool size={28} /></div>
            <h4>尚無保養紀錄</h4>
          </div>
        ) : (
          <div style={{ padding: 4 }}>
            {list.map((m, i) => (
              <div key={m.id} style={{ display: "grid", gridTemplateColumns: "auto auto 1fr auto", gap: 14, padding: "12px 16px", borderBottom: i < list.length - 1 ? "1px solid var(--line-soft)" : "none", alignItems: "center" }}>
                <div style={{ width: 32, height: 32, borderRadius: 8, background: "var(--bg-2)", color: "var(--lime)", display: "grid", placeItems: "center" }}>
                  <Icons.Tool size={14} />
                </div>
                <div>
                  <div style={{ fontSize: 12, color: "var(--fg-0)", fontWeight: 500 }}>{m.type}</div>
                  <div className="mono dimmer" style={{ fontSize: 10 }}>{m.date}</div>
                </div>
                <div style={{ fontSize: 12, color: "var(--fg-2)" }}>{m.description}</div>
                <div style={{ fontSize: 11, color: "var(--fg-3)" }}>{m.performed_by}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function SpecsAndCorrelation({ device, trends }) {
  return (
    <div className="grid-2" style={{ marginTop: 16 }}>
      <div className="card">
        <div className="card-head"><h4>設備規格</h4></div>
        <div className="card-body" style={{ display: "grid", gridTemplateColumns: "auto 1fr", rowGap: 8, columnGap: 16, fontSize: 12 }}>
          <span className="dim">型號</span><span className="val-num">{device.model}</span>
          <span className="dim">設備編號</span><span className="val-num">{device.device_id}</span>
          <span className="dim">場域</span><span>{device.site_name}</span>
          <span className="dim">資料源</span><span>{device.is_mock ? "模擬資料" : "InfluxDB 真實"}</span>
          <span className="dim">裝機日期</span><span className="mono">{device.installed_at}</span>
          <span className="dim">最後保養</span><span className="mono">{device.last_service}</span>
          <span className="dim">設計出水溫度</span><span className="val-num">{device.rated_outlet_t.toFixed(1)} °C</span>
          <span className="dim">基準功率</span><span className="val-num">{device.baseline_power.toFixed(1)} kW</span>
          <span className="dim">基準 COP</span><span className="val-num">{device.baseline_cop.toFixed(2)}</span>
          <span className="dim">累計運轉</span><span className="val-num">{device.runtime_h.toLocaleString()} h</span>
        </div>
      </div>
      <div className="card">
        <div className="card-head">
          <h4>功率 × COP 散點</h4>
          <span className="sub">能效相關性 · 近 24 小時</span>
        </div>
        <div className="card-body">
          <ScatterPower trends={trends} />
        </div>
      </div>
    </div>
  );
}

function ScatterPower({ trends }) {
  const pts = trends.power_kw.map((p, i) => ({ x: p, y: trends.cop[i] }));
  const w = 520, h = 180, pad = { l: 36, r: 12, t: 10, b: 24 };
  const xs = pts.map((p) => p.x), ys = pts.map((p) => p.y);
  const xMin = Math.min(...xs), xMax = Math.max(...xs);
  const yMin = Math.min(...ys), yMax = Math.max(...ys);
  const X = (v) => pad.l + ((v - xMin) / (xMax - xMin)) * (w - pad.l - pad.r);
  const Y = (v) => pad.t + (h - pad.t - pad.b) - ((v - yMin) / (yMax - yMin)) * (h - pad.t - pad.b);
  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      <g className="gridlines">
        {[0, 0.25, 0.5, 0.75, 1].map((f, i) => (
          <line key={i} x1={pad.l} x2={w - pad.r} y1={pad.t + f * (h - pad.t - pad.b)} y2={pad.t + f * (h - pad.t - pad.b)} />
        ))}
      </g>
      {pts.map((p, i) => (
        <circle key={i} cx={X(p.x)} cy={Y(p.y)} r="2.5" fill="var(--lime)" opacity={0.4 + (i / pts.length) * 0.5} />
      ))}
      <text x={pad.l} y={h - 4} fill="var(--fg-3)" fontFamily="var(--mono)" fontSize="10">Power (kW) →</text>
      <text x={6} y={pad.t + 4} fill="var(--fg-3)" fontFamily="var(--mono)" fontSize="10">↑ COP</text>
    </svg>
  );
}

window.PageDevice = PageDevice;
