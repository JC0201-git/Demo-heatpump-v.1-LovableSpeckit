/* global React, HPMD, Icons, StatusPill, SeverityPill, StackedBars, Donut, Heatmap,
   useApp, useLiveTick, fmtTime, ago */
// ============================================================
// Page 4 — 告警中心 Alert Center (P4)
// ============================================================
function PageAlerts() {
  const { siteId, role, alerts, acknowledgeAlert, resolveAlert, openDevice } = useApp();
  useLiveTick(6000);
  const [statusTab, setStatusTab] = React.useState("active"); // active | acknowledged | resolved | all
  const [sevFilter, setSevFilter] = React.useState("ALL");
  const [search, setSearch] = React.useState("");
  const [selected, setSelected] = React.useState(null);

  const filtered = React.useMemo(() => {
    let arr = alerts;
    if (siteId !== "ALL") arr = arr.filter((a) => a.site_id === siteId);
    if (statusTab !== "all") arr = arr.filter((a) => a.status === statusTab);
    if (sevFilter !== "ALL") arr = arr.filter((a) => a.severity === sevFilter);
    if (search) arr = arr.filter((a) => a.label.includes(search) || a.device_name.includes(search) || a.device_id.includes(search));
    return arr;
  }, [alerts, siteId, statusTab, sevFilter, search]);

  const counts = React.useMemo(() => {
    const base = alerts.filter((a) => siteId === "ALL" || a.site_id === siteId);
    return {
      active: base.filter((a) => a.status === "active").length,
      acknowledged: base.filter((a) => a.status === "acknowledged").length,
      resolved: base.filter((a) => a.status === "resolved").length,
      critical: base.filter((a) => a.severity === "critical" && a.status !== "resolved").length,
      warning: base.filter((a) => a.severity === "warning" && a.status !== "resolved").length,
      total: base.length,
    };
  }, [alerts, siteId]);

  return (
    <div>
      <div className="page-head">
        <div>
          <div className="num">P4 · ALERT CENTER</div>
          <h1>告警中心</h1>
          <div className="sub">集中式告警管理 · 確認 / 處理 / 解決全生命週期紀錄</div>
        </div>
        <div className="actions">
          {role === "operator" && (
            <button className="btn primary"><Icons.Plus size={14} />手動建立告警</button>
          )}
        </div>
      </div>

      {/* summary row */}
      <div className="grid-4" style={{ marginBottom: 16 }}>
        <SummaryStat label="未處理 (Active)" value={counts.active} color="var(--alarm)" icon={<Icons.Alarm size={18} />} sub="需立即關注" />
        <SummaryStat label="已確認 (Ack'd)" value={counts.acknowledged} color="var(--warn)" icon={<Icons.Eye size={18} />} sub="處理中" />
        <SummaryStat label="本月解決" value={counts.resolved} color="var(--ok)" icon={<Icons.Check size={18} />} sub={`平均處理 ${(2 + Math.random() * 2).toFixed(1)} 小時`} />
        <AlertDist counts={counts} />
      </div>

      {/* filters */}
      <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 12, flexWrap: "wrap" }}>
        <div className="segmented">
          <button className={statusTab === "active" ? "on" : ""} onClick={() => setStatusTab("active")}>未處理 {counts.active}</button>
          <button className={statusTab === "acknowledged" ? "on" : ""} onClick={() => setStatusTab("acknowledged")}>已確認 {counts.acknowledged}</button>
          <button className={statusTab === "resolved" ? "on" : ""} onClick={() => setStatusTab("resolved")}>已解決 {counts.resolved}</button>
          <button className={statusTab === "all" ? "on" : ""} onClick={() => setStatusTab("all")}>全部 {counts.total}</button>
        </div>
        <div className="segmented">
          <button className={sevFilter === "ALL" ? "on" : ""} onClick={() => setSevFilter("ALL")}>所有等級</button>
          <button className={sevFilter === "critical" ? "on" : ""} onClick={() => setSevFilter("critical")}>嚴重</button>
          <button className={sevFilter === "warning" ? "on" : ""} onClick={() => setSevFilter("warning")}>警告</button>
          <button className={sevFilter === "info" ? "on" : ""} onClick={() => setSevFilter("info")}>資訊</button>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6, background: "var(--bg-1)", borderRadius: 8, padding: "0 12px", height: 32, border: "1px solid var(--line-soft)", minWidth: 220 }}>
          <Icons.Search size={14} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="搜尋告警內容/設備" style={{ background: "transparent", border: 0, color: "var(--fg-0)", fontSize: 12, flex: 1, outline: "none" }} />
        </div>
        <div style={{ flex: 1 }} />
        <span className="eyebrow">顯示 {filtered.length} 筆</span>
      </div>

      <div className="grid-12">
        <div style={{ gridColumn: "span 8" }}>
          <div className="card">
            <div className="card-body" style={{ padding: 0 }}>
              {filtered.length === 0 ? (
                <div className="empty-state" style={{ padding: 60 }}>
                  <div className="ic"><Icons.Check size={36} /></div>
                  <h4>{statusTab === "active" ? "目前沒有未處理告警" : "沒有符合條件的告警"}</h4>
                  <div className="dimmer">所有告警均已處理完畢 ✨</div>
                </div>
              ) : (
                <table className="dt">
                  <thead>
                    <tr><th>等級</th><th>告警內容</th><th>設備</th><th>場域</th><th>觸發時間</th><th>已經過</th><th>狀態</th><th></th></tr>
                  </thead>
                  <tbody>
                    {filtered.slice(0, 30).map((a) => (
                      <tr key={a.id} className={selected === a.id ? "on" : ""} onClick={() => setSelected(a.id === selected ? null : a.id)}>
                        <td><SeverityPill severity={a.severity} /></td>
                        <td>
                          <div style={{ fontSize: 12, color: "var(--fg-0)" }}>{a.label}</div>
                          <span className="mono dimmer" style={{ fontSize: 10 }}>{a.code}</span>
                        </td>
                        <td>
                          <div style={{ fontSize: 12 }}>{a.device_name}</div>
                          <span className="mono dimmer" style={{ fontSize: 10 }}>{a.device_id}</span>
                        </td>
                        <td className="dim">{a.site_name}</td>
                        <td className="mono dim" style={{ fontSize: 11 }}>{fmtTime(a.triggered_at)}</td>
                        <td className="mono num">{ago(a.triggered_at)}</td>
                        <td>
                          <span className={`pill ${a.status === "resolved" ? "ok" : a.status === "acknowledged" ? "warn" : "alarm"}`}>
                            <span className="d" />
                            {a.status === "resolved" ? "已解決" : a.status === "acknowledged" ? "已確認" : "未處理"}
                          </span>
                        </td>
                        <td onClick={(e) => e.stopPropagation()}>
                          {role === "operator" && (
                            <div style={{ display: "flex", gap: 4 }}>
                              {a.status === "active" && <button className="btn" style={{ height: 24, padding: "0 8px", fontSize: 11 }} onClick={() => acknowledgeAlert(a.id, "李維運")}>確認</button>}
                              {a.status !== "resolved" && <button className="btn primary" style={{ height: 24, padding: "0 8px", fontSize: 11 }} onClick={() => resolveAlert(a.id, "李維運", "現場確認處理完成")}>解決</button>}
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>

        <div style={{ gridColumn: "span 4", display: "flex", flexDirection: "column", gap: 16 }}>
          {selected ? (
            <AlertDetail alert={alerts.find((a) => a.id === selected)} onClose={() => setSelected(null)} onOpenDevice={openDevice} />
          ) : (
            <AlertAnalytics alerts={alerts.filter((a) => siteId === "ALL" || a.site_id === siteId)} />
          )}
        </div>
      </div>
    </div>
  );
}

function SummaryStat({ label, value, color, icon, sub }) {
  return (
    <div className="kpi-card" style={{ flexDirection: "row", alignItems: "center", gap: 14, padding: 16 }}>
      <div style={{ width: 44, height: 44, borderRadius: 12, background: `color-mix(in oklab, ${color} 16%, transparent)`, color, display: "grid", placeItems: "center" }}>
        {icon}
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, color: "var(--fg-3)", fontFamily: "var(--mono)", textTransform: "uppercase", letterSpacing: ".08em" }}>{label}</div>
        <div className="val val-num" style={{ color, fontSize: 26, marginTop: 2 }}>{value}</div>
        <div style={{ fontSize: 11, color: "var(--fg-3)", marginTop: 2 }}>{sub}</div>
      </div>
    </div>
  );
}

function AlertDist({ counts }) {
  const slices = [
    { value: counts.critical, color: "var(--alarm)" },
    { value: counts.warning,  color: "var(--warn)" },
    { value: Math.max(0, counts.total - counts.critical - counts.warning), color: "var(--info)" },
  ];
  return (
    <div className="kpi-card" style={{ flexDirection: "row", alignItems: "center", gap: 14, padding: 16 }}>
      <Donut size={66} stroke={9} slices={slices} center={{ value: counts.critical + counts.warning, label: "Active" }} />
      <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", rowGap: 4, columnGap: 8, fontSize: 11 }}>
        <Row color="var(--alarm)" label="嚴重" n={counts.critical} />
        <Row color="var(--warn)"  label="警告" n={counts.warning} />
        <Row color="var(--info)"  label="資訊" n={counts.total - counts.critical - counts.warning} />
      </div>
    </div>
  );
}
function Row({ color, label, n }) {
  return (<>
    <span style={{ width: 6, height: 6, borderRadius: "50%", background: color, alignSelf: "center" }} />
    <span style={{ color: "var(--fg-2)" }}>{label}</span>
    <span className="val-num" style={{ color: "var(--fg-0)" }}>{n}</span>
  </>);
}

function AlertDetail({ alert, onClose, onOpenDevice }) {
  const { resolveAlert, acknowledgeAlert, role } = useApp();
  const [note, setNote] = React.useState("");
  return (
    <div className="card">
      <div className="card-head">
        <SeverityPill severity={alert.severity} />
        <h4 style={{ marginLeft: 4 }}>告警詳情</h4>
        <button className="btn-icon btn ghost" style={{ marginLeft: "auto", height: 24, width: 24 }} onClick={onClose}><Icons.X size={12} /></button>
      </div>
      <div className="card-body">
        <div style={{ fontSize: 16, color: "var(--fg-0)", fontWeight: 500, marginBottom: 6 }}>{alert.label}</div>
        <div className="mono dim" style={{ fontSize: 11, marginBottom: 14 }}>{alert.code} · ID #{alert.id}</div>

        <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", rowGap: 8, columnGap: 12, fontSize: 12, marginBottom: 14 }}>
          <span className="dim">設備</span>
          <a onClick={() => onOpenDevice(alert.device_id)} style={{ color: "var(--lime)", cursor: "pointer" }}>{alert.device_name} <span className="mono dimmer">{alert.device_id}</span></a>
          <span className="dim">場域</span><span>{alert.site_name}</span>
          <span className="dim">觸發時間</span><span className="mono">{fmtTime(alert.triggered_at)}</span>
          <span className="dim">已經過</span><span className="mono">{ago(alert.triggered_at)}</span>
          {alert.acknowledged_at && <><span className="dim">確認</span><span className="mono">{fmtTime(alert.acknowledged_at)} · {alert.acknowledged_by}</span></>}
          {alert.resolved_at && <><span className="dim">解決</span><span className="mono">{fmtTime(alert.resolved_at)}</span></>}
        </div>

        {alert.note && (
          <div style={{ padding: 10, background: "var(--bg-2)", borderRadius: 6, fontSize: 12, marginBottom: 14, borderLeft: "2px solid var(--ok)" }}>
            <div className="eyebrow" style={{ marginBottom: 4 }}>處理備註</div>
            {alert.note}
          </div>
        )}

        {role === "operator" && alert.status !== "resolved" && (
          <div style={{ borderTop: "1px solid var(--line-soft)", paddingTop: 14 }}>
            <div className="eyebrow" style={{ marginBottom: 6 }}>處理備註 (Resolve)</div>
            <textarea value={note} onChange={(e) => setNote(e.target.value)} rows="3" placeholder="例：清洗冷凝器後 ΔT 回穩..."
              style={{ width: "100%", padding: 10, borderRadius: 8, background: "var(--bg-2)", color: "var(--fg-0)", border: "1px solid var(--line-soft)", fontSize: 12, resize: "vertical", outline: "none" }} />
            <div style={{ display: "flex", gap: 6, marginTop: 8, justifyContent: "flex-end" }}>
              {alert.status === "active" && <button className="btn" onClick={() => acknowledgeAlert(alert.id, "李維運")}><Icons.Eye size={12} />確認接手</button>}
              <button className="btn primary" onClick={() => { resolveAlert(alert.id, "李維運", note || "現場處理完成"); onClose(); }}>
                <Icons.Check size={14} /> 標記為已解決
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function AlertAnalytics({ alerts }) {
  const byType = React.useMemo(() => {
    const map = new Map();
    alerts.forEach((a) => {
      if (!map.has(a.code)) map.set(a.code, { code: a.code, label: a.label, critical: 0, warning: 0, info: 0 });
      map.get(a.code)[a.severity]++;
    });
    return Array.from(map.values()).sort((a, b) => (b.critical + b.warning) - (a.critical + a.warning)).slice(0, 5);
  }, [alerts]);

  return (
    <>
      <div className="card">
        <div className="card-head"><h4>近 7 日趨勢</h4><span className="sub">每日告警筆數</span></div>
        <div className="card-body">
          <StackedBars data={buildDailyTrend(alerts)} width={520} height={140} colors={{ critical: "var(--alarm)", warning: "var(--warn)", info: "var(--info)" }} />
          <div style={{ display: "flex", gap: 12, fontSize: 10, fontFamily: "var(--mono)", color: "var(--fg-3)", marginTop: 8, justifyContent: "center" }}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><span style={{ width: 8, height: 8, background: "var(--alarm)", borderRadius: 2 }}/>嚴重</span>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><span style={{ width: 8, height: 8, background: "var(--warn)", borderRadius: 2 }}/>警告</span>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><span style={{ width: 8, height: 8, background: "var(--info)", borderRadius: 2 }}/>資訊</span>
          </div>
        </div>
      </div>
      <div className="card">
        <div className="card-head"><h4>告警類型分佈</h4><span className="sub">TOP 5</span></div>
        <div className="card-body" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {byType.map((t) => {
            const total = t.critical + t.warning + t.info;
            return (
              <div key={t.code}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                  <span style={{ fontSize: 11, color: "var(--fg-1)" }}>{t.label}</span>
                  <span className="mono" style={{ fontSize: 11, color: "var(--fg-0)" }}>{total}</span>
                </div>
                <div style={{ display: "flex", height: 6, borderRadius: 3, overflow: "hidden", background: "var(--bg-2)" }}>
                  <div style={{ width: `${(t.critical / total) * 100}%`, background: "var(--alarm)" }} />
                  <div style={{ width: `${(t.warning / total) * 100}%`, background: "var(--warn)" }} />
                  <div style={{ width: `${(t.info / total) * 100}%`, background: "var(--info)" }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

function buildDailyTrend(alerts) {
  // synthetic: aggregate by date over last 7 days from alerts triggered_at
  const days = [];
  const now = new Date();
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now); d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    const dayAlerts = alerts.filter((a) => a.triggered_at.startsWith(key));
    const counts = { critical: 0, warning: 0, info: 0 };
    dayAlerts.forEach((a) => counts[a.severity]++);
    // ensure at least small synthetic numbers
    if (counts.critical + counts.warning + counts.info === 0) {
      counts.critical = Math.floor(Math.random() * 3);
      counts.warning = Math.floor(Math.random() * 5);
      counts.info = Math.floor(Math.random() * 2);
    }
    days.push({
      label: `${d.getMonth() + 1}/${d.getDate()}`,
      segments: [
        { key: "info", value: counts.info },
        { key: "warning", value: counts.warning },
        { key: "critical", value: counts.critical },
      ],
    });
  }
  return days;
}

window.PageAlerts = PageAlerts;
