/* global React */
// ============================================================
// Heat Pump Monitor — Shared UI components, icons, charts
// ============================================================
// ============================================================
// Icons (lucide-style stroke icons)
// ============================================================
const I = ({ d, size = 16, fill = "none", sw = 1.6 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);
const Icons = {
  Home:    (p) => <I {...p} d="M3 11l9-7 9 7v9a1 1 0 01-1 1h-5v-6h-4v6H4a1 1 0 01-1-1v-9z" />,
  Grid:    (p) => <svg width={p.size||16} height={p.size||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>,
  Trend:   (p) => <I {...p} d="M3 17l5-6 4 4 4-7 5 8" />,
  Alarm:   (p) => <svg width={p.size||16} height={p.size||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round"><path d="M6 17h12l-1.5-2V11a4.5 4.5 0 10-9 0v4L6 17z"/><path d="M10 20a2 2 0 004 0"/></svg>,
  Bolt:    (p) => <I {...p} d="M13 2L4 14h7l-1 8 9-12h-7l1-8z" />,
  File:    (p) => <I {...p} d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z M14 2v6h6" />,
  Crown:   (p) => <I {...p} d="M3 8l4 4 5-7 5 7 4-4-2 11H5L3 8z" />,
  Search:  (p) => <svg width={p.size||16} height={p.size||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>,
  Filter:  (p) => <I {...p} d="M3 5h18l-7 9v6l-4-2v-4L3 5z" />,
  Refresh: (p) => <I {...p} d="M3 12a9 9 0 0115-6.7L21 8 M21 12a9 9 0 01-15 6.7L3 16 M21 3v5h-5 M3 21v-5h5" />,
  Settings:(p) => <svg width={p.size||16} height={p.size||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 01-4 0v-.1a1.7 1.7 0 00-1-1.5 1.7 1.7 0 00-1.8.3l-.1.1A2 2 0 113.4 17l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H2a2 2 0 010-4h.1a1.7 1.7 0 001.5-1 1.7 1.7 0 00-.3-1.8L3.2 7a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3 1.7 1.7 0 001-1.5V3a2 2 0 014 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1A2 2 0 1120.6 7l-.1.1a1.7 1.7 0 00-.3 1.8 1.7 1.7 0 001.5 1H22a2 2 0 010 4h-.1a1.7 1.7 0 00-1.5 1z"/></svg>,
  ChevronD:(p) => <I {...p} d="M6 9l6 6 6-6" />,
  ChevronR:(p) => <I {...p} d="M9 6l6 6-6 6" />,
  Check:   (p) => <I {...p} d="M4 12l5 5L20 6" />,
  X:       (p) => <I {...p} d="M5 5l14 14M19 5L5 19" />,
  Plus:    (p) => <I {...p} d="M12 5v14M5 12h14" />,
  Print:   (p) => <I {...p} d="M6 9V3h12v6M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2M6 14h12v8H6v-8z" />,
  Tool:    (p) => <I {...p} d="M14 6a4 4 0 11-1.4 7.7L6 20l-2-2 6.3-6.6A4 4 0 0114 6z" />,
  Temp:    (p) => <I {...p} d="M14 14V4a2 2 0 00-4 0v10a4 4 0 104 0z" />,
  Drop:    (p) => <I {...p} d="M12 3c-4 4-6 7-6 11a6 6 0 1012 0c0-4-2-7-6-11z" />,
  Clock:   (p) => <svg width={p.size||16} height={p.size||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>,
  Info:    (p) => <svg width={p.size||16} height={p.size||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v.01M11 12h1v4h1"/></svg>,
  Triangle:(p) => <I {...p} d="M12 4l9 16H3L12 4z" />,
  Map:     (p) => <I {...p} d="M3 7l6-3 6 3 6-3v14l-6 3-6-3-6 3V7z M9 4v17 M15 7v17" />,
  Activity:(p) => <I {...p} d="M3 12h4l3-8 4 16 3-8h4" />,
  Compress:(p) => <svg width={p.size||16} height={p.size||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><circle cx="12" cy="12" r="4"/><path d="M12 8v4l3 2"/></svg>,
  Logo:    (p) => <svg width={p.size||18} height={p.size||18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M4 18l5-12 4 8 3-4 4 8"/><circle cx="9" cy="6" r="1.6" fill="currentColor"/></svg>,
  Spark:   (p) => <I {...p} d="M12 3l1.8 4.8L18.6 9 14 11l-2 5-2-5L5.4 9l4.8-1.2L12 3z" />,
  Calendar:(p) => <I {...p} d="M3 6a2 2 0 012-2h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V6z M3 10h18 M8 2v4 M16 2v4" />,
  Download:(p) => <I {...p} d="M12 4v12 M6 12l6 6 6-6 M4 21h16" />,
  Eye:     (p) => <svg width={p.size||16} height={p.size||16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>,
};

// ============================================================
// Status helpers
// ============================================================
const STATUS = {
  ok:      { label: "正常",   cls: "ok",    en: "RUN" },
  idle:    { label: "待機",   cls: "idle",  en: "IDLE" },
  warn:    { label: "警告",   cls: "warn",  en: "WARN" },
  alarm:   { label: "異常",   cls: "alarm", en: "ALARM" },
  offline: { label: "離線",   cls: "stale", en: "OFFLINE" },
};

const RISK = {
  high: { label: "高", color: "var(--alarm)", level: 3 },
  mid:  { label: "中", color: "var(--warn)",  level: 2 },
  low:  { label: "低", color: "var(--info)",  level: 1 },
};

const SEV = {
  critical: { label: "嚴重", cls: "alarm" },
  warning:  { label: "警告", cls: "warn"  },
  info:     { label: "資訊", cls: "info"  },
};

function StatusPill({ status, dim = false }) {
  const s = STATUS[status] || STATUS.idle;
  return (
    <span className={`pill ${s.cls}`} style={dim ? { opacity: 0.65 } : null}>
      <span className="d" />
      <span>{s.label}</span>
    </span>
  );
}

function SeverityPill({ severity }) {
  const s = SEV[severity] || SEV.info;
  return <span className={`pill ${s.cls}`}><span className="d" />{s.label}</span>;
}

function RiskBadge({ level, mini = false }) {
  const r = RISK[level] || RISK.low;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      padding: mini ? "1px 6px" : "2px 9px",
      borderRadius: 5,
      fontFamily: "var(--mono)", fontSize: mini ? 9 : 10,
      letterSpacing: ".08em", textTransform: "uppercase",
      color: r.color, background: `color-mix(in oklab, ${r.color} 14%, transparent)`,
    }}>
      <span style={{ width: 5, height: 5, borderRadius: "50%", background: r.color }} />
      {r.label}風險
    </span>
  );
}

// ============================================================
// Sparkline / Line chart
// ============================================================
function Sparkline({ data, width = 80, height = 28, color = "var(--lime)", area = true }) {
  if (!data || data.length < 2) return <svg className="sparkline" width={width} height={height} />;
  const min = Math.min(...data), max = Math.max(...data);
  const range = max - min || 1;
  const stepX = width / (data.length - 1);
  const pts = data.map((v, i) => [i * stepX, height - ((v - min) / range) * (height - 2) - 1]);
  const line = pts.map((p, i) => (i === 0 ? `M${p[0]},${p[1]}` : `L${p[0]},${p[1]}`)).join(" ");
  const areaPath = `${line} L${width},${height} L0,${height} Z`;
  return (
    <svg className="sparkline" width={width} height={height} preserveAspectRatio="none">
      {area && <path d={areaPath} fill={color} opacity="0.12" />}
      <path d={line} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function LineChart({ series, width = 600, height = 220, yLabel = "", xLabels = [], yRange, padding = { top: 12, right: 8, bottom: 24, left: 38 }, threshold }) {
  const inner = { w: width - padding.left - padding.right, h: height - padding.top - padding.bottom };
  const all = series.flatMap((s) => s.data.filter((v) => v != null));
  const lo = yRange?.[0] ?? Math.min(...all);
  const hi = yRange?.[1] ?? Math.max(...all);
  const range = hi - lo || 1;
  const yScale = (v) => padding.top + inner.h - ((v - lo) / range) * inner.h;
  const xScale = (i, n) => padding.left + (i / (n - 1)) * inner.w;
  const ticks = 4;
  const yTicks = Array.from({ length: ticks + 1 }, (_, k) => lo + (k / ticks) * range);
  return (
    <svg width="100%" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" style={{ display: "block" }}>
      {/* gridlines */}
      <g className="gridlines">
        {yTicks.map((t, i) => (
          <line key={i} x1={padding.left} x2={padding.left + inner.w} y1={yScale(t)} y2={yScale(t)} />
        ))}
      </g>
      {/* threshold band */}
      {threshold && (
        <g>
          <line x1={padding.left} x2={padding.left + inner.w} y1={yScale(threshold.warn)} y2={yScale(threshold.warn)} stroke="var(--warn)" strokeWidth="1" strokeDasharray="4 4" opacity="0.5" />
          <line x1={padding.left} x2={padding.left + inner.w} y1={yScale(threshold.crit)} y2={yScale(threshold.crit)} stroke="var(--alarm)" strokeWidth="1" strokeDasharray="4 4" opacity="0.55" />
        </g>
      )}
      {/* y axis */}
      <g className="axis">
        {yTicks.map((t, i) => (
          <text key={i} x={padding.left - 8} y={yScale(t) + 3} textAnchor="end">{Math.round(t * 10) / 10}</text>
        ))}
      </g>
      {/* x axis labels */}
      <g className="axis">
        {xLabels.map((l, i) => (
          <text key={i} x={padding.left + (i / (xLabels.length - 1)) * inner.w} y={height - 6} textAnchor="middle">{l}</text>
        ))}
      </g>
      {/* series */}
      {series.map((s, si) => {
        const n = s.data.length;
        let path = "";
        s.data.forEach((v, i) => {
          if (v == null) { path += " M0 0"; return; }
          const x = xScale(i, n), y = yScale(v);
          path += i === 0 ? `M${x},${y}` : `L${x},${y}`;
        });
        return (
          <g key={si}>
            {s.area && (
              <path d={`${path} L${xScale(n - 1, n)},${yScale(lo)} L${xScale(0, n)},${yScale(lo)} Z`} fill={s.color} opacity="0.1" />
            )}
            <path d={path} fill="none" stroke={s.color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
          </g>
        );
      })}
      {yLabel && <text x={6} y={14} fill="var(--fg-3)" fontFamily="var(--mono)" fontSize="10">{yLabel}</text>}
    </svg>
  );
}

// ============================================================
// Donut / stacked / heatmap
// ============================================================
function Donut({ slices, size = 120, stroke = 14, center }) {
  const r = size / 2 - stroke / 2;
  const c = 2 * Math.PI * r;
  const total = slices.reduce((s, x) => s + x.value, 0) || 1;
  let acc = 0;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size/2} cy={size/2} r={r} stroke="var(--bg-2)" strokeWidth={stroke} fill="none" />
      {slices.map((sl, i) => {
        const frac = sl.value / total;
        const dash = `${frac * c} ${c}`;
        const offset = -acc * c;
        acc += frac;
        return (
          <circle key={i} cx={size/2} cy={size/2} r={r} stroke={sl.color} strokeWidth={stroke} fill="none"
            strokeDasharray={dash} strokeDashoffset={offset}
            transform={`rotate(-90 ${size/2} ${size/2})`} strokeLinecap="butt" />
        );
      })}
      {center && (
        <foreignObject x="0" y="0" width={size} height={size}>
          <div style={{ width: size, height: size, display: "grid", placeItems: "center", color: "var(--fg-0)" }}>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "var(--mono)", fontSize: 22, fontWeight: 500 }}>{center.value}</div>
              <div style={{ fontSize: 10, color: "var(--fg-3)", fontFamily: "var(--mono)", textTransform: "uppercase", letterSpacing: ".08em" }}>{center.label}</div>
            </div>
          </div>
        </foreignObject>
      )}
    </svg>
  );
}

function StackedBars({ data, width = 480, height = 120, colors = {} }) {
  // data: [{label, segments:[{key,value}]}]
  const max = Math.max(...data.map((d) => d.segments.reduce((s, x) => s + x.value, 0))) || 1;
  const bw = (width - 16) / data.length;
  return (
    <svg width="100%" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" style={{ display: "block" }}>
      {data.map((d, i) => {
        let y = height - 24;
        const total = d.segments.reduce((s, x) => s + x.value, 0);
        return (
          <g key={i}>
            {d.segments.map((s, si) => {
              const h = (s.value / max) * (height - 32);
              y -= h;
              return <rect key={si} x={i * bw + 6} y={y} width={bw - 6} height={h} fill={colors[s.key] || "var(--lime)"} rx="2" />;
            })}
            <text x={i * bw + bw / 2} y={height - 8} textAnchor="middle" fill="var(--fg-3)" fontFamily="var(--mono)" fontSize="10">{d.label}</text>
            {total > 0 && (
              <text x={i * bw + bw / 2} y={height - 24 - (total / max) * (height - 32) - 4} textAnchor="middle" fill="var(--fg-1)" fontFamily="var(--mono)" fontSize="10">{total}</text>
            )}
          </g>
        );
      })}
    </svg>
  );
}

function Heatmap({ rows, cols, valueFn, colorFn, width = 540, height = 160, rowLabels, colLabels }) {
  const cellW = (width - 60) / cols;
  const cellH = (height - 22) / rows;
  const cells = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const v = valueFn(r, c);
      cells.push(
        <rect key={`${r}-${c}`} x={60 + c * cellW + 1} y={r * cellH + 1} width={cellW - 2} height={cellH - 2} fill={colorFn(v)} rx="1" />
      );
    }
  }
  return (
    <svg width="100%" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" style={{ display: "block" }}>
      {cells}
      {rowLabels && rowLabels.map((l, i) => (
        <text key={i} x={54} y={i * cellH + cellH / 2 + 4} textAnchor="end" fill="var(--fg-3)" fontFamily="var(--mono)" fontSize="10">{l}</text>
      ))}
      {colLabels && colLabels.map((l, i) => (
        <text key={i} x={60 + i * cellW + cellW / 2} y={height - 4} textAnchor="middle" fill="var(--fg-3)" fontFamily="var(--mono)" fontSize="10">{l}</text>
      ))}
    </svg>
  );
}

// ============================================================
// Empty / not-found / no permission
// ============================================================
function EmptyState({ icon, title, sub }) {
  return (
    <div className="empty-state">
      <div className="ic">{icon}</div>
      <h4>{title}</h4>
      <div className="dimmer">{sub}</div>
    </div>
  );
}

function NoPermission() {
  return (
    <div className="empty-state" style={{ padding: 96 }}>
      <div className="ic"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4"><rect x="4" y="11" width="16" height="9" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/></svg></div>
      <h4>無存取權限</h4>
      <div className="dimmer">此頁面僅高層管理者可瀏覽。請切換角色，或聯絡系統管理員。</div>
    </div>
  );
}

// ============================================================
// Live ticker — drives realtime micro-updates
// ============================================================
function useLiveTick(intervalMs = 6000) {
  const [tick, setTick] = React.useState(0);
  React.useEffect(() => {
    const i = setInterval(() => setTick((t) => t + 1), intervalMs);
    return () => clearInterval(i);
  }, [intervalMs]);
  return tick;
}

function useClock() {
  const [t, setT] = React.useState(new Date());
  React.useEffect(() => {
    const i = setInterval(() => setT(new Date()), 1000);
    return () => clearInterval(i);
  }, []);
  return t;
}

function fmtTime(d) {
  if (!d) return "—";
  const date = d instanceof Date ? d : new Date(d);
  const pad = (n) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
function fmtDuration(ms) {
  if (ms == null) return "—";
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 48) return `${h}h ${m % 60}m`;
  return `${Math.floor(h / 24)}d ${h % 24}h`;
}
function ago(iso) {
  return fmtDuration(Date.now() - new Date(iso).getTime());
}

// expose
Object.assign(window, {
  Icons, STATUS, RISK, SEV,
  StatusPill, SeverityPill, RiskBadge,
  Sparkline, LineChart, Donut, StackedBars, Heatmap,
  EmptyState, NoPermission,
  useLiveTick, useClock,
  fmtTime, fmtDuration, ago,
});
