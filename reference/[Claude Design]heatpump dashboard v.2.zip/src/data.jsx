/* global React */
// ============================================================
// Heat Pump Monitor — Mock Data Store
// 3 sites · 80 devices (3 real + 77 simulated) · alerts · snapshots
// Deterministic seed → consistent across reloads
// ============================================================

(function () {
  // ---- seeded RNG ----
  function mulberry32(seed) {
    return function () {
      let t = seed += 0x6D2B79F5;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const rng = mulberry32(42);
  const rand = (min, max) => min + rng() * (max - min);
  const pick = (arr) => arr[Math.floor(rng() * arr.length)];
  const choose = (p) => rng() < p;

  // ---- sites ----
  const SITES = [
    { id: "SITE01", name: "拉拉手游泳學院", city: "台中", deviceCount: 28, kind: "泳池熱泵 / 熱水供應" },
    { id: "SITE02", name: "宜蘭洗衣廠", city: "宜蘭", deviceCount: 26, kind: "工業熱水 / 高溫清洗" },
    { id: "SITE03", name: "宜蘭罐頭工廠", city: "宜蘭", deviceCount: 26, kind: "蒸氣輔助 / 製程熱回收" },
  ];

  // ---- devices ----
  const MODELS = ["HX-150A", "HX-220C", "HX-320E", "HXi-450P"];
  const RISK_NOTES = [
    "壓縮機振動值偏高，列入觀察",
    "去年 11 月更換循環泵，運轉穩定",
    "進出水溫差略低於設計值",
    "Δp 偏離基準線，安排排程清洗",
    "高溫告警次數本月偏多",
    "雙週前完成保養，目前正常",
    "電流持續偏高，疑似冷媒不足",
    "客戶反映異音，已派員確認",
  ];

  const devices = [];
  let realCount = 0;
  for (const site of SITES) {
    for (let i = 1; i <= site.deviceCount; i++) {
      const id = `${site.id}-${String(i).padStart(3, "0")}`;
      const isReal = site.id === "SITE01" && i <= 3;
      if (isReal) realCount++;
      const realNames = ["主泳池熱泵 A", "副泳池熱泵 B", "熱水供應泵"];
      const name = isReal ? realNames[i - 1] : `${site.kind.split(" / ")[0]} #${i}`;
      const installYear = 2021 + Math.floor(rng() * 5);
      const installMonth = 1 + Math.floor(rng() * 12);
      const model = pick(MODELS);
      const baselineCOP = 3.2 + rng() * 1.4;
      const baselinePower = 8 + rng() * 14; // kW
      const ratedOutletT = 45 + rng() * 18;

      // Status distribution: weighted to mostly OK
      let status;
      const r = rng();
      if (r < 0.66) status = "ok";
      else if (r < 0.82) status = "idle";
      else if (r < 0.91) status = "warn";
      else if (r < 0.97) status = "alarm";
      else status = "offline";

      // Risk level: manually assigned (high / mid / low / unassigned)
      const riskRoll = rng();
      let riskLevel = "low";
      if (status === "alarm") riskLevel = "high";
      else if (status === "warn") riskLevel = riskRoll < 0.6 ? "high" : "mid";
      else if (riskRoll < 0.08) riskLevel = "mid";
      else if (riskRoll < 0.02) riskLevel = "high";

      devices.push({
        device_id: id,
        name,
        site_id: site.id,
        site_name: site.name,
        model,
        installed_at: `${installYear}-${String(installMonth).padStart(2, "0")}-01`,
        is_mock: !isReal,
        status,
        risk_level: riskLevel,
        risk_note: pick(RISK_NOTES),
        risk_assigned_by: pick(["李維運", "陳工程", "張組長", "黃技師"]),
        risk_assigned_at: `2026-05-${String(10 + Math.floor(rng() * 14)).padStart(2, "0")}`,
        baseline_cop: baselineCOP,
        baseline_power: baselinePower,
        rated_outlet_t: ratedOutletT,
        runtime_h: Math.floor(1200 + rng() * 9000),
        last_service: `2026-${String(1 + Math.floor(rng() * 4)).padStart(2, "0")}-${String(1 + Math.floor(rng() * 28)).padStart(2, "0")}`,
      });
    }
  }

  // ---- realtime parameters ----
  function readingsFor(device, t = Date.now()) {
    const seed = (device.device_id.charCodeAt(7) * 31 + device.device_id.charCodeAt(8)) >>> 0;
    const r = mulberry32(seed + Math.floor(t / 6000));
    const status = device.status;
    const base = {
      temp_outlet: device.rated_outlet_t + r() * 3 - 1.5,
      temp_inlet: device.rated_outlet_t - 8 + r() * 2,
      temp_ambient: 22 + r() * 6,
      pressure_high: 22 + r() * 4,
      pressure_low: 4 + r() * 1.5,
      flow_lpm: 60 + r() * 30,
      power_kw: device.baseline_power + (r() - 0.5) * 2,
      current_a: 14 + r() * 4,
      cop: device.baseline_cop + (r() - 0.5) * 0.3,
      energy_today: 80 + r() * 60,
      vibration: 1.5 + r() * 1.2,
      compressor_hz: 50 + Math.floor(r() * 12),
      pump_on: !choose(0.05),
    };
    if (status === "idle") {
      base.power_kw = 0.2 + r() * 0.4; base.compressor_hz = 0; base.cop = 0; base.current_a = 0.5 + r();
      base.temp_outlet = device.rated_outlet_t - 4 + r();
    } else if (status === "warn") {
      base.temp_outlet += 4; base.pressure_high += 3.5; base.vibration += 1.2;
    } else if (status === "alarm") {
      base.temp_outlet += 8; base.pressure_high += 6; base.vibration += 2.4;
      base.cop = base.cop * 0.6;
      if (choose(0.4)) base.flow_lpm = 0;
    } else if (status === "offline") {
      return null;
    }
    return base;
  }

  // ---- alerts ----
  const ALERT_TYPES = [
    { code: "T_OUT_HIGH", label: "出水溫度過高", severity: "warning" },
    { code: "T_OUT_CRIT", label: "出水溫度超危急值", severity: "critical" },
    { code: "P_HIGH",     label: "高壓壓力異常",   severity: "warning" },
    { code: "P_CRIT",     label: "高壓壓力危急",   severity: "critical" },
    { code: "I_HIGH",     label: "壓縮機電流偏高", severity: "warning" },
    { code: "FLOW_LOW",   label: "循環流量過低",   severity: "critical" },
    { code: "VIB_HIGH",   label: "壓縮機振動過大", severity: "warning" },
    { code: "OFFLINE",    label: "設備離線 > 5 min", severity: "critical" },
    { code: "MANUAL",     label: "人工建立 — 客戶反映異音", severity: "info" },
    { code: "DEFROST",    label: "除霜循環啟動", severity: "info" },
  ];

  const alerts = [];
  const now = Date.now();
  let alertId = 8000;
  for (const d of devices) {
    let count = 0;
    if (d.status === "alarm") count = 1 + Math.floor(rng() * 3);
    else if (d.status === "warn") count = 1 + Math.floor(rng() * 2);
    else if (d.status === "offline") count = 1;
    else if (rng() < 0.35) count = 1 + Math.floor(rng() * 2);
    // historical alerts
    const histCount = Math.floor(rng() * 5);
    const total = count + histCount;
    for (let i = 0; i < total; i++) {
      const type = pick(ALERT_TYPES);
      const isActive = i < count;
      const ageMin = isActive ? Math.floor(rng() * 240) : (60 + Math.floor(rng() * 60 * 24 * 21));
      const triggered = new Date(now - ageMin * 60000);
      const status = isActive
        ? (rng() < 0.4 ? "acknowledged" : "active")
        : "resolved";
      alerts.push({
        id: ++alertId,
        device_id: d.device_id,
        device_name: d.name,
        site_id: d.site_id,
        site_name: d.site_name,
        code: type.code,
        label: type.label,
        severity: type.severity,
        triggered_at: triggered.toISOString(),
        acknowledged_at: status !== "active" ? new Date(triggered.getTime() + 5 * 60000).toISOString() : null,
        resolved_at: status === "resolved" ? new Date(triggered.getTime() + (30 + rng() * 300) * 60000).toISOString() : null,
        acknowledged_by: status !== "active" ? pick(["李維運", "陳工程", "張組長"]) : null,
        note: status === "resolved" ? pick([
          "更換高壓開關後恢復正常",
          "清洗冷凝器，溫度回穩",
          "重新校正流量計，數值正常",
          "現場確認誤觸發，已調整門檻",
          "補充冷媒後 COP 回升",
          "重啟壓縮機後恢復",
        ]) : null,
        status,
      });
    }
  }
  alerts.sort((a, b) => new Date(b.triggered_at) - new Date(a.triggered_at));

  // ---- maintenance ----
  const maintenance = [];
  let mid = 5000;
  for (const d of devices) {
    if (rng() < 0.7) {
      const records = 1 + Math.floor(rng() * 3);
      for (let i = 0; i < records; i++) {
        maintenance.push({
          id: ++mid,
          device_id: d.device_id,
          date: `2026-${String(1 + Math.floor(rng() * 5)).padStart(2, "0")}-${String(1 + Math.floor(rng() * 28)).padStart(2, "0")}`,
          performed_by: pick(["陳工程", "李維運", "外包-冠軒工程", "外包-合眾科技"]),
          type: pick(["定期保養", "故障維修", "預防性更換", "清洗"]),
          description: pick([
            "更換冷凝器風扇皮帶；測試運轉正常",
            "清洗蒸發器表面、補充冷媒 R134a 0.8kg",
            "更換循環泵機械軸封；壓力恢復",
            "校正高低壓開關門檻；測試切換正常",
            "清潔板式熱交換器；ΔT 恢復至 8.2°C",
            "更換感溫線；讀值恢復正常",
          ]),
        });
      }
    }
  }
  maintenance.sort((a, b) => b.date.localeCompare(a.date));

  // ---- snapshot trends (last 24h, 5-min granularity = 288 points) ----
  function genTrend(device, fieldKey, baseFn) {
    const seed = (device.device_id.charCodeAt(7) * 53 + device.device_id.charCodeAt(8) * 7) >>> 0;
    const r = mulberry32(seed);
    const pts = [];
    for (let i = 0; i < 288; i++) {
      const base = baseFn(i);
      const noise = (r() - 0.5) * (fieldKey === "cop" ? 0.2 : fieldKey === "power_kw" ? 1.5 : 2);
      pts.push(base + noise);
    }
    return pts;
  }
  function buildTrends(device) {
    const status = device.status;
    return {
      temp_outlet: genTrend(device, "temp_outlet", (i) => device.rated_outlet_t + Math.sin(i / 24) * 1.8 + (status === "alarm" ? 5 + i * 0.005 : 0)),
      power_kw: genTrend(device, "power_kw", (i) => device.baseline_power + Math.sin(i / 36 + 1) * 2.5),
      cop: genTrend(device, "cop", (i) => device.baseline_cop + Math.sin(i / 28) * 0.25 - (status === "alarm" ? 0.4 : 0)),
      pressure_high: genTrend(device, "pressure_high", (i) => 22 + Math.sin(i / 32 + 2) * 2),
    };
  }

  // ---- KPIs aggregated ----
  function sitesSummary() {
    return SITES.map((s) => {
      const ds = devices.filter((d) => d.site_id === s.id);
      const counts = { ok: 0, warn: 0, alarm: 0, offline: 0, idle: 0 };
      ds.forEach((d) => counts[d.status]++);
      const alertsCount = alerts.filter((a) => a.site_id === s.id && a.status !== "resolved").length;
      const totalPower = ds.reduce((sum, d) => sum + (d.status === "offline" || d.status === "idle" ? 0 : d.baseline_power), 0);
      const avgCop = ds.reduce((sum, d) => sum + (d.status === "offline" || d.status === "idle" ? 0 : d.baseline_cop), 0) / Math.max(ds.length, 1);
      return { ...s, devices: ds, counts, alerts_active: alertsCount, total_power: totalPower, avg_cop: avgCop };
    });
  }

  // ---- exposed API ----
  window.HPMD = {
    sites: SITES,
    devices,
    alerts,
    maintenance,
    readingsFor,
    buildTrends,
    sitesSummary,
    realDeviceCount: realCount,
    rand, rng, choose, pick,
  };
})();
