/* global React, HPMD, Icons, StatusPill, Sparkline, Donut, LineChart, Heatmap,
   useApp, useClock */
// ============================================================
// Page 6 — 老闆決策頁 Executive Dashboard (P6, manager only)
// ============================================================
function PageExec() {
  const clock = useClock();
  const summary = React.useMemo(() => HPMD.sitesSummary(), []);
  const { setSiteId, setPage } = useApp();

  const totalDevices = HPMD.devices.length;
  const totalActiveAlerts = HPMD.alerts.filter((a) => a.status !== "resolved").length;
  const totalHealthy = HPMD.devices.filter((d) => d.status === "ok" || d.status === "idle").length;
  const overallHealth = Math.round((totalHealthy / totalDevices) * 100);
  const totalPower = summary.reduce((s, x) => s + x.total_power, 0);
  const avgCop = summary.reduce((s, x) => s + x.avg_cop, 0) / summary.length;

  return (
    <div>
      <div className="page-head">
        <div>
          <div className="num">P6 · EXECUTIVE</div>
          <h1>決策總覽</h1>
          <div className="sub">跨場域經營視角 · 即時健康度 · 環比趨勢</div>
        </div>
        <div className="actions">
          <span className="meta-pill"><span className="dot"/>LIVE · {clock.toTimeString().slice(0, 8)}</span>
          <button className="btn"><Icons.Download size={14} />匯出簡報</button>
        </div>
      </div>

      {/* hero KPIs */}
      <div className="grid-4" style={{ marginBottom: 16 }}>
        <BigStat label="整體設備健康度" value={`${overallHealth}%`} sub={`${totalHealthy} / ${totalDevices} 台運轉中`} color="var(--ok)" trend="▲ 1.2%" />
        <BigStat label="本月總用電" value="48,920" unit="kWh" sub="▼ 3.4% vs 上月" color="var(--lime)" />
        <BigStat label="平均 COP" value={avgCop.toFixed(2)} sub="基準 3.50 · 達標" color="var(--info)" trend="▲ 0.12" />
        <BigStat label="未處理告警" value={totalActiveAlerts} sub={`含 ${HPMD.alerts.filter((a) => a.severity === "critical" && a.status !== "resolved").length} 筆嚴重事件`} color={totalActiveAlerts > 10 ? "var(--alarm)" : "var(--warn)"} />
      </div>

      {/* site comparison */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="card-head">
          <div className="ic"><Icons.Map size={14} /></div>
          <h4>場域比較</h4>
          <span className="sub">點擊場域 → 跳轉至設備總覽</span>
        </div>
        <div className="card-body">
          <div style={{ display: "grid", gridTemplateColumns: `repeat(${summary.length}, 1fr)`, gap: 12 }}>
            {summary.map((s) => <SiteCard key={s.id} site={s} onClick={() => { setSiteId(s.id); setPage("overview"); }} />)}
          </div>
        </div>
      </div>

      <div className="grid-12">
        {/* alert trend */}
        <div style={{ gridColumn: "span 8" }}>
          <div className="card">
            <div className="card-head">
              <div className="ic"><Icons.Trend size={14} /></div>
              <h4>能耗 vs 告警趨勢</h4>
              <span className="sub">過去 12 個月</span>
              <div className="segmented" style={{ marginLeft: "auto" }}>
                <button className="on">12M</button>
                <button>6M</button>
                <button>3M</button>
              </div>
            </div>
            <div className="card-body">
              <LineChart
                width={760} height={260}
                xLabels={["6/25", "7/25", "8/25", "9/25", "10/25", "11/25", "12/25", "1/26", "2/26", "3/26", "4/26", "5/26"]}
                series={[
                  { data: [42, 44, 47, 50, 53, 56, 58, 56, 54, 51, 49, 48], color: "var(--lime)", area: true },
                  { data: [12, 14, 18, 16, 22, 24, 28, 22, 19, 17, 15, 14], color: "var(--alarm)", area: false },
                ]}
                yRange={[0, 60]}
              />
              <div style={{ display: "flex", gap: 16, marginTop: 8, fontSize: 11, fontFamily: "var(--mono)", color: "var(--fg-2)" }}>
                <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><span style={{ width: 12, height: 2, background: "var(--lime)", display: "inline-block" }} />能耗 (千 kWh)</span>
                <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><span style={{ width: 12, height: 2, background: "var(--alarm)", display: "inline-block" }} />告警筆數</span>
                <span style={{ marginLeft: "auto", color: "var(--fg-3)" }}>本月能耗 ▼ 3.4% · 告警 ▼ 6.7%</span>
              </div>
            </div>
          </div>
        </div>

        {/* alert heatmap */}
        <div style={{ gridColumn: "span 4" }}>
          <div className="card" style={{ height: "100%" }}>
            <div className="card-head">
              <div className="ic"><Icons.Activity size={14} /></div>
              <h4>本月告警熱圖</h4>
              <span className="sub">場域 × 日期</span>
            </div>
            <div className="card-body">
              <Heatmap
                rows={3} cols={20}
                rowLabels={["SITE01", "SITE02", "SITE03"]}
                colLabels={["1", "5", "10", "15", "20", "25", "30"]}
                width={360} height={140}
                valueFn={(r, c) => {
                  // deterministic
                  return Math.abs(Math.sin((r + 1) * 7 + c * 1.3)) * 4;
                }}
                colorFn={(v) => {
                  const intensity = Math.min(v / 4, 1);
                  if (intensity < 0.2) return "var(--bg-2)";
                  if (intensity < 0.4) return "color-mix(in oklab, var(--warn) 30%, var(--bg-2))";
                  if (intensity < 0.7) return "color-mix(in oklab, var(--warn) 70%, var(--bg-2))";
                  return "var(--alarm)";
                }}
              />
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8, fontSize: 10, fontFamily: "var(--mono)", color: "var(--fg-3)" }}>
                <span>低</span>
                <div style={{ display: "flex", gap: 2 }}>
                  {[0.1, 0.3, 0.5, 0.7, 1].map((f, i) => (
                    <div key={i} style={{ width: 18, height: 8, background: f < 0.2 ? "var(--bg-2)" : f < 0.4 ? "color-mix(in oklab, var(--warn) 30%, var(--bg-2))" : f < 0.7 ? "color-mix(in oklab, var(--warn) 70%, var(--bg-2))" : "var(--alarm)" }} />
                  ))}
                </div>
                <span>高</span>
              </div>
            </div>
          </div>
        </div>

        {/* needs-attention */}
        <div style={{ gridColumn: "span 8" }}>
          <div className="card">
            <div className="card-head">
              <div className="ic" style={{ color: "var(--warn)" }}><Icons.Triangle size={14} /></div>
              <h4>需要關注</h4>
              <span className="sub">本月告警環比變化</span>
            </div>
            <div className="card-body" style={{ padding: 0 }}>
              <table className="dt">
                <thead>
                  <tr><th>場域</th><th style={{ textAlign: "right" }}>本月告警</th><th style={{ textAlign: "right" }}>上月告警</th><th style={{ textAlign: "right" }}>環比</th><th>狀態</th><th>建議行動</th></tr>
                </thead>
                <tbody>
                  {summary.map((s, i) => {
                    const cur = s.alerts_active + 5 + i * 2;
                    const prev = cur - (i === 0 ? 6 : i === 1 ? -3 : 1);
                    const change = ((cur - prev) / Math.max(prev, 1)) * 100;
                    const needAttention = change >= 30 && cur - prev >= 3;
                    return (
                      <tr key={s.id} style={{ cursor: "default" }}>
                        <td>
                          <div style={{ fontSize: 12 }}>{s.name}</div>
                          <span className="mono dimmer" style={{ fontSize: 10 }}>{s.id} · {s.city}</span>
                        </td>
                        <td className="num">{cur}</td>
                        <td className="num dim">{prev}</td>
                        <td className="num" style={{ color: change > 0 ? (needAttention ? "var(--alarm)" : "var(--warn)") : "var(--ok)" }}>
                          {change > 0 ? "▲" : "▼"} {Math.abs(change).toFixed(1)}%
                        </td>
                        <td>
                          {needAttention ? (
                            <span className="pill alarm"><span className="d"/>需要關注</span>
                          ) : change > 0 ? (
                            <span className="pill warn"><span className="d"/>持續觀察</span>
                          ) : (
                            <span className="pill ok"><span className="d"/>表現穩定</span>
                          )}
                        </td>
                        <td className="dim" style={{ fontSize: 11 }}>{needAttention ? "排程現場巡檢" : change > 0 ? "持續追蹤趨勢" : "維持現況"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* recommendation */}
        <div style={{ gridColumn: "span 4" }}>
          <div className="card" style={{ height: "100%" }}>
            <div className="card-head">
              <div className="ic"><Icons.Spark size={14} /></div>
              <h4>洞察建議</h4>
            </div>
            <div className="card-body" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <Insight
                tone="ok"
                title="能效持續優化"
                body="本月平均 COP 達 3.6，較上季提升 7%，建議向客戶提交季報以強化合約價值。"
              />
              <Insight
                tone="warn"
                title="SITE03 告警上升"
                body="罐頭工廠本月告警筆數環比 +42%，建議優先安排現場巡檢與冷媒檢測。"
              />
              <Insight
                tone="info"
                title="預測性維護機會"
                body="7 台設備累計運轉時數已超 4,000 小時，建議納入下季排程性保養。"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function BigStat({ label, value, unit, sub, color, trend }) {
  return (
    <div className="kpi-card" style={{ padding: 18 }}>
      <div className="head">{label}</div>
      <div className="val val-num" style={{ color, fontSize: 36, marginTop: 4 }}>{value}{unit && <span style={{ fontSize: 14, color: "var(--fg-3)", marginLeft: 4 }}>{unit}</span>}</div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginTop: 4 }}>
        <span style={{ fontSize: 11, color: "var(--fg-3)" }}>{sub}</span>
        {trend && <span className="mono" style={{ fontSize: 11, color: "var(--ok)" }}>{trend}</span>}
      </div>
    </div>
  );
}

function SiteCard({ site, onClick }) {
  const healthy = site.counts.ok + site.counts.idle;
  const pct = Math.round((healthy / site.devices.length) * 100);
  return (
    <div className="card" style={{ cursor: "pointer", transition: "transform .15s, box-shadow .15s" }}
      onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "var(--shadow-raised)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "var(--shadow-card)"; }}
      onClick={onClick}>
      <div style={{ padding: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div className="mono dimmer" style={{ fontSize: 10 }}>{site.id} · {site.city}</div>
            <div style={{ fontSize: 15, color: "var(--fg-0)", fontWeight: 600, marginTop: 2 }}>{site.name}</div>
          </div>
          <span className="val-num" style={{ fontSize: 28, color: pct > 90 ? "var(--ok)" : pct > 70 ? "var(--warn)" : "var(--alarm)" }}>{pct}<span style={{ fontSize: 12 }}>%</span></span>
        </div>
        <div className="risk-bar" style={{ marginTop: 12, marginBottom: 10, height: 10 }}>
          <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: `${pct}%`, background: pct > 90 ? "var(--ok)" : pct > 70 ? "var(--warn)" : "var(--alarm)", borderRadius: 4 }} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 4, fontSize: 10, fontFamily: "var(--mono)" }}>
          <Counter color="var(--ok)" n={site.counts.ok} l="正常" />
          <Counter color="var(--warn)" n={site.counts.warn} l="警告" />
          <Counter color="var(--alarm)" n={site.counts.alarm} l="異常" />
          <Counter color="var(--info)" n={site.counts.idle} l="待機" />
          <Counter color="var(--stale)" n={site.counts.offline} l="離線" />
        </div>
        <div style={{ marginTop: 12, paddingTop: 12, borderTop: "1px solid var(--line-soft)", display: "flex", justifyContent: "space-between", fontSize: 11, fontFamily: "var(--mono)", color: "var(--fg-2)" }}>
          <span>{site.total_power.toFixed(0)} kW · {site.alerts_active} 告警</span>
          <span style={{ color: "var(--fg-3)" }}>COP {site.avg_cop.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}
function Counter({ color, n, l }) {
  return (
    <div style={{ background: "var(--bg-2)", padding: "6px 4px", borderRadius: 5, textAlign: "center", borderTop: `2px solid ${color}` }}>
      <div className="val-num" style={{ color, fontSize: 14 }}>{n}</div>
      <div className="dimmer" style={{ fontSize: 9 }}>{l}</div>
    </div>
  );
}

function Insight({ tone, title, body }) {
  const color = tone === "ok" ? "var(--ok)" : tone === "warn" ? "var(--warn)" : "var(--info)";
  return (
    <div style={{ padding: 12, borderRadius: 8, background: `color-mix(in oklab, ${color} 10%, var(--bg-2))`, borderLeft: `3px solid ${color}` }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
        <Icons.Spark size={12} />
        <span style={{ fontSize: 12, color: "var(--fg-0)", fontWeight: 500 }}>{title}</span>
      </div>
      <div style={{ fontSize: 11, color: "var(--fg-2)", lineHeight: 1.5 }}>{body}</div>
    </div>
  );
}

window.PageExec = PageExec;
